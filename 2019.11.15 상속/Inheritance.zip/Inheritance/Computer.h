#pragma once
#include "Login.h"

class Computer : public Login
{
private:
	string m_ComputerName;
	string m_CurState;
	string m_GPUName;
	string m_CPUName;
	int m_Memory;
public:
	Computer();
	void ShowComputerInfo();
	void ShowFunc();
	void On();
	void Off();
	void ComputerMenu(Info* member, int index);
	void MainMenu();
	~Computer();
};

