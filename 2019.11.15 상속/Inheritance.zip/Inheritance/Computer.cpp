#include "Computer.h"



Computer::Computer()
{
	m_ComputerName = "����ȣ ��ǻ��";
	m_CurState = "Off";
	m_GPUName = "GTX1060Ti";
	m_CPUName = "I7";
	m_Memory = 16;
}

void Computer::ShowComputerInfo()
{
	system("cls");
	cout << "�� ǰ �� : " << m_ComputerName << endl;
	cout << "���� ���� : " << m_CurState << endl;
	cout << "�׷���ī�� : " << m_GPUName << endl;
	cout << "C P U : " << m_CPUName << endl;
	cout << "�� �� �� : " << m_Memory << "G" << endl;
	system("pause");
}

void Computer::ShowFunc()
{
	int select;

	while (1)
	{
		system("cls");
		cout << "1.�� �� ��" << endl;
		cout << "2.�� �� ��" << endl;
		cout << "3.�� �� ��" << endl;
		cout << "4.���ư���" << endl;
		cout << "���� >>>>> ";
		cin >> select;

		switch (select)
		{
		case 1:
			system("calc");
			system("pause");
			break;
		case 2:
			system("notepad");
			system("pause");
			break;
		case 3:
			system("mspaint");
			system("pause");
			break;
		case 4:
			return;
		}
	}
}

void Computer::On()
{
	cout << m_ComputerName << " On" << endl;
	Sleep(3000);
}

void Computer::Off()
{
	for (int i = 5; i > 0; i--)
	{
		cout << "off " << i << " ����" << endl;
		Sleep(1000);
	}
}

void Computer::ComputerMenu(Info * member, int index)
{
	int select;

	while (1)
	{
		system("cls");
		cout << "===== ȯ �� �� �� �� =====" << endl;
		cout << "1.��ǻ�� ����" << endl;
		cout << "2.���" << endl;
		cout << "3.ȸ�� ����" << endl;
		cout << "4.ȸ�� ���� ����" << endl;
		cout << "5.off" << endl;
		cout << "�Է� >> ";
		cin >> select;

		switch (select)
		{
		case 1:
			ShowComputerInfo();
			break;
		case 2:
			ShowFunc();
			break;
		case 3:
			ShowInfo(member, index);
			system("pause");
			break;
		case 4:
			ChangeInfo(member, index);
			break;
		case 5:
			Off();
			return;
		}
	}
}

void Computer::MainMenu()
{
	bool bOnState = true;
	while (bOnState)
	{
		LoginMenu(&bOnState);
		if (m_LoginSuccess)
		{
			On();
			ComputerMenu(m_Member, m_LoginIndex);
		}
	}
}


Computer::~Computer()
{
}
