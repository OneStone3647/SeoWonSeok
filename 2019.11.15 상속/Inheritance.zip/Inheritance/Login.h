#pragma once
#include <iostream>
#include <string>
#include <Windows.h>
#include <crtdbg.h>

#define MAX 10

using namespace std;

struct Info
{
	string m_Id;
	string m_Password;
	string m_Name;
	int m_Age;
	int m_PhoneNum;
	int m_Mileage;
};

class Login
{
protected:
	Info* m_Member;
	int m_Index;
	int m_LoginIndex;
	bool m_LoginSuccess;
public:
	Login();
	void Init();
	void LoginMenu(bool* state);
	bool EnglishCheck(string str);
	bool LengthCheck(string str, int length);
	bool IDSameCheck(string str, Info* member, int index);
	void SetID(Info* member, int index);
	bool NumberCheck(string str);
	bool PWSameCheck(string str, string tmp);
	void SetPassword(Info* member, int index);
	void SetElse(Info* member, int index);
	bool CheckID(string str, Info* member, int index);
	bool CheckPW(string str, Info* member, int index);
	void ShowInfo(Info* member, int index);
	void LoginCheck(Info* member, int index, int* loginIndex, bool* loginSuccess);
	void ChangeInfo(Info*member, int index);
	~Login();
};

