#pragma once
#include "include.h"

class Pay
{
private:
	int m_day;
	int m_hour;
	int m_hourPay;
public:
	void SetPay();
	void CalcuPay(int day, int hour = 8, int hourPay = 7500);
public:
	Pay();
	~Pay();
};

