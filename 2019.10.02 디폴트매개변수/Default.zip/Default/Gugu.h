#pragma once
#include "include.h"

class Gugu
{
private:
	int m_minNum, m_maxNum;
	bool bState;
public:
	void SetNum();
	void SetGuGuDan(int minNum = 2, int maxNum = 9);
	void ShowGuGuDan();
public:
	Gugu();
	~Gugu();
};

