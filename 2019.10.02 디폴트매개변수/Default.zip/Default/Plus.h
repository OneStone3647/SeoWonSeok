#pragma once
#include "include.h"

class Plus
{
private:
	int m_num = 10;
public:
	void setNum();
	void PlusNum(int num = 10);
public:
	Plus();
	~Plus();
};

