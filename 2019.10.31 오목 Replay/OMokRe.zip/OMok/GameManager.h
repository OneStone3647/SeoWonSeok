#pragma once
#include "Interface.h"
#include "PlayerManager.h"

class GameManager
{
private:
	int m_MapWidth, m_MapHeight;
	int* m_MapWidthptr;
	int * m_MapHeightptr;
	DrawManager m_DrawManager;
	Interface m_Interface;
	PlayerManager m_PlayerManager;
	bool m_bIsPlaying;
	int m_Turn;
	bool m_bUndo;
	bool m_bCheck;
public:
	GameManager();
	void DrawMenu();
	void DrawOption();
	void Play();
	void SaveReplay(int turn);
	void PlayReplay();
	~GameManager();
};

