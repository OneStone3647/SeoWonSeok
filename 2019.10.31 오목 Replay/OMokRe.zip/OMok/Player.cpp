#include "Player.h"



Player::Player()
{
	m_Stone = NULL;
	m_MapWidth = 20;
	m_MapHeight = 20;
}

void Player::SetPlayer(string teamName, int width, int height)
{
	m_TeamName = teamName;

	m_MaxStoneNum = width * height / 2;
	m_StoneIndex = 0;
	if (m_Stone != NULL)
	{
		delete[] m_Stone;
	}
	m_Stone = new Stone[m_MaxStoneNum];

	m_MapWidth = width;
	m_MapHeight = height;

	m_X = width / 2;
	if (m_X % 2 == 1)
	{
		m_X++;
	}
	m_Y = height / 2;

	m_Undo = 5;
}

void Player::SetStone(int teamName, int stoneShapeNum)
{
	m_TeamNum = teamName;

	if (m_TeamNum == PLAYER1)
	{
		switch (stoneShapeNum)
		{
		case 1:
			m_StoneShape = "��";
			break;
		case 2:
			m_StoneShape = "��";
			break;
		case 3:
			m_StoneShape = "��";
			break;
		case 4:
			m_StoneShape = "��";
			break;
		}
	}

	if (m_TeamNum == PLAYER2)
	{
		switch (stoneShapeNum)
		{
		case 1:
			m_StoneShape = "��";
			break;
		case 2:
			m_StoneShape = "��";
			break;
		case 3:
			m_StoneShape = "��";
			break;
		case 4:
			m_StoneShape = "��";
			break;
		}
	}
}

void Player::SetCursor(int teamNum, int cursorShapeNum)
{
	m_TeamNum = teamNum;

	if (m_TeamNum == PLAYER1)
	{
		switch (cursorShapeNum)
		{
		case 1:
			m_CursorShape = "��";
			break;
		case 2:
			m_CursorShape = "��";
			break;
		case 3:
			m_CursorShape = "��";
			break;
		case 4:
			m_CursorShape = "��";
			break;
		}
	}

	if (m_TeamNum == PLAYER2)
	{
		switch (cursorShapeNum)
		{
		case 1:
			m_CursorShape = "��";
			break;
		case 2:
			m_CursorShape = "��";
			break;
		case 3:
			m_CursorShape = "��";
			break;
		case 4:
			m_CursorShape = "��";
			break;
		}
	}
}

void Player::PutStone()
{
	m_Stone[m_StoneIndex].SetX(m_X);
	m_Stone[m_StoneIndex].SetY(m_Y);
	m_StoneIndex++;
}

void Player::UndoStone()
{
	m_Stone[m_StoneIndex - 1].SetX(0);
	m_Stone[m_StoneIndex - 1].SetY(0);
	m_StoneIndex--;
}

bool Player::FineStone(int x, int y)
{
	for (int i = 0; i <= m_StoneIndex; i++)
	{
		if (m_Stone[i].GetX() == x && m_Stone[i].GetY() == y)
		{
			return true;
		}
	}
	return false;
}

bool Player::CheckVictoryHorizontal()		// ����
{
	int CountLeft = 0;
	int CountRight = 0;
	for (int i = 0; i < m_StoneIndex; i++)
	{
		for (int j = i + 1; j < m_StoneIndex; j++)
		{
			int x = m_Stone[i].GetX();
			int y = m_Stone[i].GetY();
			int x2 = m_Stone[j].GetX();
			int y2 = m_Stone[j].GetY();
			if (x - 1 == x2 && y == y2)
			{
				CountLeft++;
				break;
			}
			if (x == x2 - 1 && y == y2)
			{
				CountRight++;
				break;
			}
		}
	}
	if (CountLeft == 4)
	{
		return true;
	}
	else if (CountRight == 4)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Player::CheckVictoryVertical()		// ����
{
	int CountUp = 0;
	int CountDown = 0;
	for (int i = 0; i < m_StoneIndex; i++)
	{
		for (int j = i + 1; j < m_StoneIndex; j++)
		{
			int x = m_Stone[i].GetX();
			int y = m_Stone[i].GetY();
			int x2 = m_Stone[j].GetX();
			int y2 = m_Stone[j].GetY();
			if (x == x2 && y - 1== y2)
			{
				CountUp++;
				break;
			}
			if (x == x2 && y == y2 - 1)
			{
				CountDown++;
				break;
			}
		}
	}
	if (CountUp == 4)
	{
		return true;
	}
	else if (CountDown == 4)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Player::CheckVictoryRightUP()	// ������ �� �밢 + ���� �Ʒ� �밢
{
	int CountRightUp = 0;
	int CountLeftDown = 0;
	for (int i = 0; i < m_StoneIndex; i++)
	{
		for (int j = i + 1; j < m_StoneIndex; j++)
		{
			int x = m_Stone[i].GetX();
			int y = m_Stone[i].GetY();
			int x2 = m_Stone[j].GetX();
			int y2 = m_Stone[j].GetY();
			if (x == x2 + 1 && y == y2 - 1)
			{
				CountRightUp++;
				break;
			}
			if (x + 1 == x2 && y - 1 == y2)
			{
				CountLeftDown++;
				break;
			}
		}
	}
	if (CountRightUp == 4)
	{
		return true;
	}
	else if (CountLeftDown == 4)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Player::CheckVictoryLeftUP()	//���� �� �밢 + ������ �Ʒ� �밢
{
	int CountLeftUp = 0;
	int CountRightDown = 0;
	for (int i = 0; i < m_StoneIndex; i++)
	{
		for (int j = i + 1; j < m_StoneIndex; j++)
		{
			int x = m_Stone[i].GetX();
			int y = m_Stone[i].GetY();
			int x2 = m_Stone[j].GetX();
			int y2 = m_Stone[j].GetY();
			if (x - 1 == x2 && y - 1 == y2)
			{
				CountLeftUp++;
				break;
			}
			if (x +1 == x2 && y + 1 == y2)
			{
				CountRightDown++;
				break;
			}
		}
	}
	if (CountLeftUp == 4)
	{
		return true;
	}
	else if (CountRightDown == 4)
	{
		return true;
	}
	else
	{
		return false;
	}
}


Player::~Player()
{
	if (m_Stone != NULL)
	{
		delete[] m_Stone;
		m_Stone = NULL;
	}
}
