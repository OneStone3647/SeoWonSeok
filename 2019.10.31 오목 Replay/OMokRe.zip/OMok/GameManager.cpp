#include "GameManager.h"



GameManager::GameManager()
{
	m_MapWidth = 20;
	m_MapHeight = 20;

	m_MapWidthptr = &m_MapWidth;
	m_MapHeightptr = &m_MapHeight;

	m_bIsPlaying = false;
	m_bUndo = false;
	m_bCheck = true;
}

void GameManager::DrawMenu()
{
	int select;
	bool bFlag = true;
	while (1)
	{
		m_Interface.MainMenu(m_MapWidth, m_MapHeight);
		select = 0;
		cin >> select;
		switch (select)
		{
		case 1:
			m_bIsPlaying = true;
			m_PlayerManager.Init(m_MapWidth, m_MapHeight);
			Play();
			break;
		case 2:
			PlayReplay();
			break;
		case 3:
			m_bIsPlaying = false;
			DrawOption();
			break;
		case 4:
			return;
		}
	}
}

void GameManager::DrawOption()
{
	int select;
	bool bFlag = true;
	while (bFlag)
	{
		int m_Y = m_MapHeight / 2;
		system("cls");
		m_Interface.OptionMenu(m_MapWidth, m_MapHeight);
		select = 0;
		cin >> select;
		switch (select)
		{
		case 1:
			if (m_bIsPlaying)
			{
				m_Interface.AccessDenied();
			}
			else
			{
				m_Interface.MapSizeSet(m_MapWidthptr, m_MapHeightptr);
			}
			break;
		case 2:
			m_Interface.CursorCustom();
			select = 0;
			cin >> select;
			switch (select)
			{
			case 1:
			case 2:
			case 3:
			case 4:
				m_PlayerManager.SetPlayerCursor(select);
				system("pause");
				break;
			case 5:
				break;
			}
			break;
		case 3:
			m_Interface.StoneCustom();
			select = 0;
			cin >> select;
			switch (select)
			{
			case 1:
			case 2:
			case 3:
			case 4:
				m_PlayerManager.SetPlayerStone(select);
				system("pause");
				break;
			case 5:
				break;
			}
			break;
		case 4:
			if (m_bIsPlaying)
			{
				m_Interface.AccessDenied();
			}
			else
			{
				bFlag = true;
				while (bFlag)
				{
					system("cls");
					m_Interface.UndoCountSet();
					int UndoCount;
					bFlag = true;
					select = 0;
					cin >> select;
					system("cls");
					switch (select)
					{
					case 1:
						while (bFlag)
						{
							m_Interface.SetUndoDis();
							cin >> UndoCount;
							if (UndoCount >= 0 && UndoCount <= 10)
							{
								m_PlayerManager.SetPlayerUndo(UndoCount);
								bFlag = false;
							}
							else
							{
								m_Interface.SetUndoFail();
							}
						}
						break;
					case 2:
						m_Interface.UndoOffDis();
						m_PlayerManager.SetPlayerUndo(0);
						break;
					case 3:
						bFlag = false;
						break;
					}
				}
				bFlag = true;
			}
			break;
		case 5:
			bFlag = false;
		}
	}
}

void GameManager::Play()
{
	m_Turn = 1;
	int* m_Turnptr = &m_Turn;
	bool* m_bIsPlayingptr = &m_bIsPlaying;
	bool* m_bUndoptr = &m_bUndo;
	int Change;
	bool bOpenOption = false;
	bool* bOpenOptionptr = &bOpenOption;
	m_DrawManager.DrawMap(m_MapWidth, m_MapHeight);
	int m_Y = m_MapHeight / 2;
	while (m_bIsPlaying)
	{
		Change = m_Turn % 2;
		switch (Change)
		{
		case 0:
			if (m_bUndo)
			{
				m_bUndo = m_PlayerManager.IsUndo(m_PlayerManager.GetPlayer(PLAYER2));
			}
			m_Interface.DrawInfo(m_PlayerManager.GetPlayer(PLAYER2), m_Turn);
			if (m_PlayerManager.Input(m_PlayerManager.GetPlayer(PLAYER2), m_Turnptr, m_bIsPlayingptr, m_bUndoptr, bOpenOptionptr))
			{
				m_Interface.VictoryDis(PLAYER2);
				SaveReplay(m_Turn);
				return;
			}
			if (bOpenOption)
			{
				DrawOption();
				system("cls");
				m_DrawManager.DrawMap(m_MapWidth, m_MapHeight);
				m_PlayerManager.DrawAllStone();
				m_Interface.DrawInfo(m_PlayerManager.GetPlayer(PLAYER2), m_Turn);
				bOpenOption = false;
			}
			break;
		case 1:
			if (m_bUndo)
			{
				m_bUndo = m_PlayerManager.IsUndo(m_PlayerManager.GetPlayer(PLAYER1));
			}
			m_Interface.DrawInfo(m_PlayerManager.GetPlayer(PLAYER1), m_Turn);
			if (m_PlayerManager.Input(m_PlayerManager.GetPlayer(PLAYER1), m_Turnptr, m_bIsPlayingptr, m_bUndoptr, bOpenOptionptr))
			{
				m_Interface.VictoryDis(PLAYER1);
				SaveReplay(m_Turn);
				return;
			}
			if (bOpenOption)
			{
				DrawOption();
				system("cls");
				m_DrawManager.DrawMap(m_MapWidth, m_MapHeight);
				m_PlayerManager.DrawAllStone();
				m_Interface.DrawInfo(m_PlayerManager.GetPlayer(PLAYER1), m_Turn);
				bOpenOption = false;
			}
			break;
		}
	}
}

void GameManager::SaveReplay(int turn)
{
	int StoneIndex;
	if (m_PlayerManager.GetPlayer(PLAYER1)->GetStoneIdnex() > m_PlayerManager.GetPlayer(PLAYER2)->GetStoneIdnex())
	{
		StoneIndex = m_PlayerManager.GetPlayer(PLAYER1)->GetStoneIdnex();
	}
	else
	{
		StoneIndex = m_PlayerManager.GetPlayer(PLAYER2)->GetStoneIdnex();
	}
	ofstream save;
	save.open("Replay.txt");
	if (save.is_open())
	{
		save << turn << endl;
		save << m_PlayerManager.GetPlayer(PLAYER1)->GetTeamName() << " " << m_PlayerManager.GetPlayer(PLAYER2)->GetTeamName() << endl;
		save << m_PlayerManager.GetPlayer(PLAYER1)->GetStoneShape() << " " << m_PlayerManager.GetPlayer(PLAYER2)->GetStoneShape() << endl;
		for (int i = 0; i < StoneIndex; i++)
		{
			if (m_PlayerManager.GetPlayer(PLAYER1)->GetStoneX(i) != NULL && m_PlayerManager.GetPlayer(PLAYER1)->GetStoneY(i) != NULL)
			{
				save << m_PlayerManager.GetPlayer(PLAYER1)->GetStoneX(i) << " " << m_PlayerManager.GetPlayer(PLAYER1)->GetStoneY(i) << endl;
			}
			if (m_PlayerManager.GetPlayer(PLAYER2)->GetStoneX(i) != NULL && m_PlayerManager.GetPlayer(PLAYER2)->GetStoneY(i) != NULL)
			{
				save << m_PlayerManager.GetPlayer(PLAYER2)->GetStoneX(i) << " " << m_PlayerManager.GetPlayer(PLAYER2)->GetStoneY(i) << endl;
			}
		}
		save.close();
	}
}

void GameManager::PlayReplay()
{
	ifstream load;
	load.open("Replay.txt");
	if (!load.is_open())
	{
		m_Interface.NoReplayFile();
	}
	else
	{
	}
}


GameManager::~GameManager()
{
}
