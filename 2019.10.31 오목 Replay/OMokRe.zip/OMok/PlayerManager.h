#pragma once
#include "Player.h"
#include "DrawManager.h"

class PlayerManager
{
private:
	int m_MapWidth, m_MapHeight;
	DrawManager m_DrawManager;
	Player* m_Player1;
	Player* m_Player2;
public:
	PlayerManager();
	Player* GetPlayer(int PlayerNum);
	void Init(int Width, int Height);
	void SetPlayerCursor(int CursorShapeNum);
	void SetPlayerStone(int StoneShapeNum);
	void SetPlayerUndo(int SetCount);
	void DrawPlayer(int teamNum);
	void DrawPlayer(Player* Player);
	void DrawPlayer(Player* Player, int X, int Y);
	void ErasePlayer(Player* Player);
	bool CheckStone(int x, int y);
	void DrawAllStone();
	void EraseLastStone(Player* Player);
	bool IsUndo(Player* player);
	bool Input(Player* player, int* turn, bool* bIsPlaying, bool* bUndo, bool*bOption);
	~PlayerManager();
};

