#pragma once
#include "DrawManager.h"
#include "PlayerManager.h"

class Interface
{
private:
	int m_MapWidth;
	int m_MapHeight;
	int m_Y;
	DrawManager m_DrawManager;
public:
	Interface();
	void MainMenu(int width, int height);
	void OptionMenu(int width, int height);
	void MapSizeSet(int* width, int* height);
	void CursorCustom();
	void StoneCustom();
	void UndoCountSet();
	void SetUndoDis();
	void SetUndoFail();
	void UndoOffDis();
	void DrawInfo(Player* player, int turn);
	void AccessDenied();
	void VictoryDis(int teamNum);
	void NoReplayFile();
	~Interface();
};

