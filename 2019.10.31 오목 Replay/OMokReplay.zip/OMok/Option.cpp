#include "Option.h"



Option::Option()
{
	m_Width = WIDTH;
	m_Height = HEIGHT;
	
}

void Option::OptionMenu(int * width, int * height, bool bPlayState, Player * player1P, Player * player2P)
{
	m_Width = *width;
	m_Height = *height;
	while (1)
	{
		int Height = m_Height / 2;
		system("cls");
		m_DrawManager.DrawBox(m_Width, m_Height);
		m_DrawManager.DrawMidText("= Option =", m_Width, Height - 6);
		m_DrawManager.DrawMidText("1.Map Size Set", m_Width, Height - 4);
		m_DrawManager.DrawMidText("2.Cursor Custom", m_Width, Height - 2);
		m_DrawManager.DrawMidText("3.Stone Custom", m_Width, Height);
		m_DrawManager.DrawMidText("4.Undo Count Set", m_Width, Height + 2);
		m_DrawManager.DrawMidText("5.Return", m_Width, Height + 4);
		m_DrawManager.DrawMidText("�Է� : ", m_Width, Height + 6);
		m_DrawManager.gotoxy(m_Width + 4, Height + 6);
		int select;
		cin >> select;
		switch (select)
		{
		case OPTIONMENU_MAPSIZESET:
			MapSizeSet(width, height, bPlayState);
			break;
		case OPTIONMENU_CURSORCUSTOM:
			CursorCustom(player1P, player2P);
			break;
		case OPTIONMENU_STONECUSTOM:
			StoneCustom(player1P, player2P);
			break;
		case OPTIONMENU_UNDOCOUNTSET:
			UndoCountSet(player1P, player2P, bPlayState);
			break;
		case OPTIONMENU_RETURN:
			return;
		}
	}
}

void Option::MapSizeSet(int * width, int * height, bool bPlayState)
{
	int NewWidth;
	int NewHeight;
	int Height = m_Height / 2;
	while (1)
	{
		system("cls");
		if (bPlayState == false)
		{
			m_DrawManager.DrawBox(m_Width, m_Height);
			m_DrawManager.DrawMidText("Width : ", m_Width, Height);
			cin >> NewWidth;
			m_DrawManager.DrawMidText("Height : ", m_Width, Height + 2);
			cin >> NewHeight;
			if ((NewWidth >= 20 && NewWidth <= 90) && (NewHeight >= 20 && NewHeight <= 45))
			{
				*width = NewWidth;
				*height = NewHeight;
				m_Width = NewWidth;
				m_Height = NewHeight;
				return;
			}
			else
			{
				m_DrawManager.DrawMidText("���� �Ұ���", m_Width, Height);
				m_DrawManager.DrawMidText("(���� : 20 ~ 90, ���� : 20 ~ 45)", m_Width, Height + 2);
				system("pause");
			}
		}
		else
		{
			m_DrawManager.DrawMidText("���� �Ұ���", m_Width, Height);
			m_DrawManager.DrawMidText("(Game Play��)", m_Width, Height + 2);
			system("pause");
			return;
		}
	}
}

void Option::CursorCustom(Player * player1P, Player * player2P)
{
	int Height = m_Height / 2;
	system("cls");
	m_DrawManager.DrawBox(m_Width, m_Height);
	m_DrawManager.DrawMidText("= Set Cursor =", m_Width, Height - 6);
	m_DrawManager.DrawMidText("1.��, ��", m_Width, Height - 4);
	m_DrawManager.DrawMidText("2.��, ��", m_Width, Height - 2);
	m_DrawManager.DrawMidText("3.��, ��", m_Width, Height);
	m_DrawManager.DrawMidText("4.��, ��", m_Width, Height + 2);
	m_DrawManager.DrawMidText("5.Return", m_Width, Height + 4);
	m_DrawManager.DrawMidText("�Է� : ", m_Width, Height + 6);
	int select;
	cin >> select;
	switch (select)
	{
	case 1:
		player1P->SetCursorShape("��");
		player2P->SetCursorShape("��");
		break;
	case 2:
		player1P->SetCursorShape("��");
		player2P->SetCursorShape("��");
		break;
	case 3:
		player1P->SetCursorShape("��");
		player2P->SetCursorShape("��");
		break;
	case 4:
		player1P->SetCursorShape("��");
		player2P->SetCursorShape("��");
		break;
	case 5:
		return;
	}
}

void Option::StoneCustom(Player * player1P, Player * player2P)
{
	int Height = m_Height / 2;
	system("cls");
	m_DrawManager.DrawBox(m_Width, m_Height);
	m_DrawManager.DrawMidText("= Set Stone =", m_Width, Height - 6);
	m_DrawManager.DrawMidText("1.��, ��", m_Width, Height - 4);
	m_DrawManager.DrawMidText("2.��, ��", m_Width, Height - 2);
	m_DrawManager.DrawMidText("3.��, ��", m_Width, Height);
	m_DrawManager.DrawMidText("4.��, ��", m_Width, Height + 2);
	m_DrawManager.DrawMidText("5.Return", m_Width, Height + 4);
	m_DrawManager.DrawMidText("�Է� : ", m_Width, Height + 6);
	int select;
	cin >> select;
	switch (select)
	{
	case 1:
		player1P->SetStoneShape("��");
		player2P->SetStoneShape("��");
		break;
	case 2:
		player1P->SetStoneShape("��");
		player2P->SetStoneShape("��");
		break;
	case 3:
		player1P->SetStoneShape("��");
		player2P->SetStoneShape("��");
		break;
	case 4:
		player1P->SetStoneShape("��");
		player2P->SetStoneShape("��");
		break;
	case 5:
		return;
	}
}

void Option::UndoCountSet(Player * player1P, Player * player2P, bool bPlayState)
{
	int Height = m_Height / 2;
	system("cls");
	if (bPlayState == false)
	{
		m_DrawManager.DrawBox(m_Width, m_Height);
		m_DrawManager.DrawMidText("= Set Undo =", m_Width, Height - 4);
		m_DrawManager.DrawMidText("1.Set Undo Count", m_Width, Height - 2);
		m_DrawManager.DrawMidText("2.Undo Off", m_Width, Height);
		m_DrawManager.DrawMidText("3.Return", m_Width, Height + 2);
		m_DrawManager.DrawMidText("�Է� : ", m_Width, Height + 4);
		int select;
		cin >> select;
		switch (select)
		{
		case 1:
			while (1)
			{
				system("cls");
				m_DrawManager.DrawBox(m_Width, m_Height);
				m_DrawManager.DrawMidText("������ Ƚ�� �Է�(�ִ� 10ȸ) : ", m_Width, Height);
				int undoCount;
				cin >> undoCount;
				if (undoCount >= 0 && undoCount <= 10)
				{
					player1P->SetUndo(undoCount);
					player2P->SetUndo(undoCount);
					break;
				}
				else
				{
					m_DrawManager.DrawMidText("������ ���� �ʽ��ϴ�. (0 ~ 10)", m_Width, Height + 2);
					system("pause");
				}
			}
		case 2:
			system("cls");
			m_DrawManager.DrawBox(m_Width, m_Height);
			m_DrawManager.DrawMidText("������ Off", m_Width, Height);
			player1P->SetUndo(0);
			player2P->SetUndo(0);
			system("pause");
			break;
		case 3:
			return;
		}
	}

}


Option::~Option()
{
}
