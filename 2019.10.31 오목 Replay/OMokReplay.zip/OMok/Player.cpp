#include "Player.h"



Player::Player()
{
	m_StoneList = NULL;
	m_UndoCount = DEFAULT_UNDOCOUNT;
}

void Player::SetPlayer(int width, int height)
{
	m_Cursor.m_X = width / 2;
	if (m_Cursor.m_X & 2 == 1)
	{
		m_Cursor.m_X++;
	}
	m_Cursor.m_Y = height / 2;

	if (m_StoneList != NULL)
	{
		delete[] m_StoneList;
	}
	m_StoneList = new Point[(width * height) / 2];
	m_StoneCount = 0;
	m_bVictoryState = false;
}

void Player::DrawCursor()
{
	m_DrawManager.DrawPoint(m_CursorShape, m_Cursor.m_X, m_Cursor.m_Y);
}

void Player::Move(char key, int x, int y)
{
	switch (key)
	{
	case KEY_UP:
		if (m_Cursor.m_Y > 0)
		{
			m_Cursor.m_Y--;
		}
		break;
	case KEY_LEFT:
		if (m_Cursor.m_X > 0)
		{
			m_Cursor.m_X--;
		}
		break;
	case KEY_DOWN:
		if (m_Cursor.m_Y + 1 < y)
		{
			m_Cursor.m_Y++;
		}
		break;
	case KEY_RIGHT:
		if (m_Cursor.m_X + 1 < x)
		{
			m_Cursor.m_X++;
		}		
		break;
	}
}

bool Player::CheckStone(int x, int y)
{
	for (int i = 0; i < m_StoneCount; i++)
	{
		if (m_StoneList[i].m_X == x && m_StoneList[i].m_Y == y)
		{
			return true;
		}
	}
	return false;
}

void Player::DrawStone(int x, int y)
{
	if (CheckStone(x, y))
	{
		m_DrawManager.DrawPoint(m_StoneShape, x, y);
	}
}

void Player::DrawAllStone()
{
	for (int i = 0; i < m_StoneCount; i++)
	{
		m_DrawManager.DrawPoint(m_StoneShape, m_StoneList[i].m_X, m_StoneList[i].m_Y);
	}
}

void Player::PutStone()
{
	if (CheckStone(m_Cursor.m_X, m_Cursor.m_Y) == false)
	{
		m_StoneList[m_StoneCount].m_X = m_Cursor.m_X;
		m_StoneList[m_StoneCount].m_Y = m_Cursor.m_Y;
		DrawStone(m_Cursor.m_X, m_Cursor.m_Y);
		m_StoneCount++;
	}
}

void Player::PutStone(int x, int y)
{
	m_StoneList[m_StoneCount].m_X = x;
	m_StoneList[m_StoneCount].m_Y = y;
	m_DrawManager.DrawPoint(m_StoneShape, x, y);
	m_StoneCount++;
}

bool Player::CheckVictory()
{
	if (CheckVictoryHorizontal() || CheckVictoryVertical() || CheckVictoryRightUP() || CheckVictoryLeftUP())
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Player::CheckVictoryHorizontal()			// ����
{
	int CountLeft = 0;
	int CountRight = 0;
	for (int i = 0; i < m_StoneCount; i++)
	{
		for (int j = i + 1; j < m_StoneCount; j++)
		{
			int x = m_StoneList[i].m_X;
			int y = m_StoneList[i].m_Y;
			int x2 = m_StoneList[j].m_X;
			int y2 = m_StoneList[j].m_Y;
			if (x - 1 == x2 && y == y2)
			{
				CountLeft++;
				break;
			}
			if (x + 1 == x2 && y == y2)
			{
				CountRight++;
				break;
			}
		}
	}
	if (CountLeft == 4 || CountRight == 4)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Player::CheckVictoryVertical()		// ����
{
	int CountUp = 0;
	int CountDown = 0;
	for (int i = 0; i < m_StoneCount; i++)
	{
		for (int j = i + 1; j < m_StoneCount; j++)
		{
			int x = m_StoneList[i].m_X;
			int y = m_StoneList[i].m_Y;
			int x2 = m_StoneList[j].m_X;
			int y2 = m_StoneList[j].m_Y;
			if (x == x2 && y - 1 == y2)
			{
				CountUp++;
				break;
			}
			if (x == x2 && y + 1 == y2)
			{
				CountDown++;
				break;
			}
		}
	}
	if (CountUp == 4 || CountDown == 4)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Player::CheckVictoryRightUP()		// ������ �� �밢 + ���� �Ʒ� �밢
{
	int CountRightUp = 0;
	int CountLeftDown = 0;
	for (int i = 0; i < m_StoneCount; i++)
	{
		for (int j = i + 1; j < m_StoneCount; j++)
		{
			int x = m_StoneList[i].m_X;
			int y = m_StoneList[i].m_Y;
			int x2 = m_StoneList[j].m_X;
			int y2 = m_StoneList[j].m_Y;
			if (x - 1 == x2 && y + 1 == y2)
			{
				CountRightUp++;
				break;
			}
			if (x + 1 == x2 && y - 1 == y2)
			{
				CountLeftDown++;
				break;
			}
		}
	}
	if (CountRightUp == 4 || CountLeftDown == 4)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Player::CheckVictoryLeftUP()		// ���� �� �밢 + ������ �Ʒ� �밢
{
	int CountLeftUp = 0;
	int CountRightDown = 0;
	for (int i = 0; i < m_StoneCount; i++)
	{
		for (int j = i + 1; j < m_StoneCount; j++)
		{
			int x = m_StoneList[i].m_X;
			int y = m_StoneList[i].m_Y;
			int x2 = m_StoneList[j].m_X;
			int y2 = m_StoneList[j].m_Y;
			if (x - 1 == x2 && y - 1 == y2)
			{
				CountLeftUp++;
				break;
			}
			if (x + 1 == x2 && y + 1 == y2)
			{
				CountRightDown++;
				break;
			}
		}
	}
	if (CountLeftUp == 4 || CountRightDown == 4)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void Player::Undo(int width, int height)
{
	m_UndoCount--;
	m_StoneCount--;
	m_DrawManager.ErasePoint(m_StoneList[m_StoneCount].m_X, m_StoneList[m_StoneCount].m_Y);
	m_DrawManager.ReDrawPoint(m_StoneList[m_StoneCount].m_X, m_StoneList[m_StoneCount].m_Y, width, height);
}


Player::~Player()
{
}
