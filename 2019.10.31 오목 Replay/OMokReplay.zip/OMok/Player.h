#pragma once
#include "Mecro.h"
#include "DrawManager.h"

#define DEFAULT_UNDOCOUNT 5

enum PLAYER
{
	PLAYER_2P,
	PLAYER_1P,
	PLAYER_END
};

enum KEY
{
	KEY_UP = 'w',
	KEY_LEFT = 'a',
	KEY_DOWN = 's',
	KEY_RIGHT = 'd',
	KEY_PUT = 13,
	KEY_ESC = 27,
	KEY_UNDO = 'n',
	KEY_OPTION = 'p'
};

struct Point
{
	int m_X;
	int m_Y;
};

class Player
{
private:
	string m_PlayerName;
	Point* m_StoneList;
	Point m_Cursor;
	string m_StoneShape;
	string m_CursorShape;
	int m_StoneCount;
	int m_UndoCount;
	bool m_bVictoryState;
	DrawManager m_DrawManager;
public:
	Player();
	void SetPlayer(int width, int height);
	void DrawCursor();
	void Move(char key, int x, int y);
	bool CheckStone(int x, int y);
	void DrawStone(int x, int y);
	void DrawAllStone();
	void PutStone();
	void PutStone(int x, int y);
	bool CheckVictory();
	bool CheckVictoryHorizontal();
	bool CheckVictoryVertical();
	bool CheckVictoryRightUP();
	bool CheckVictoryLeftUP();
	void Undo(int width, int height);
	inline int GetUndo()
	{
		return m_UndoCount;
	}
	inline void SetUndo(int undoCount)
	{
		m_UndoCount = undoCount;
	}
	inline string GetPlayerName()
	{
		return m_PlayerName;
	}
	inline void SetPlayerName()
	{
		cin >> m_PlayerName;
	}
	inline void SetPlayerName(string playerName)
	{
		m_PlayerName = playerName;
	}
	inline string GetStoneShape()
	{
		return m_StoneShape;
	}
	inline void SetStoneShape(string stoneShape)
	{
		m_StoneShape = stoneShape;
	}
	inline string GetCursorShape()
	{
		return m_CursorShape;
	}
	inline void SetCursorShape(string cursorShape)
	{
		m_CursorShape = cursorShape;
	}
	inline Point GetCursor()
	{
		return m_Cursor;
	}
	inline int GetStoneCount()
	{
		return m_StoneCount;
	}
	inline Point* GetStoneList()
	{
		return m_StoneList;
	}
	~Player();
};

