#include "DrawManager.h"



DrawManager::DrawManager()
{
}

void DrawManager::ErasePoint(int x, int y)
{
	gotoxy(x * 2, y);
	cout << "  ";
	gotoxy(-1, -1);
	return;
}

void DrawManager::ReDrawPoint(int x, int y, int Width, int Height)
{
	int reX = x * 2;
	int reY = y;
	gotoxy(reX, reY);
	if (reX == 0)
	{
		if (reY == 0)
		{
			cout << "��";
		}
		else if (reY == Height - 1)
		{
			cout << "��";
		}
		else
		{
			cout << "��";
		}
	}
	else if (reX + 2 == Width * 2)
	{
		if (reY == 0)
		{
			cout << "��";
		}
		else if (reY == Height - 1)
		{
			cout << "��";
		}
		else
		{
			cout << "��";
		}
	}
	else
	{
		if (reY == 0)
		{
			cout << "��";
		}
		else if (reY == Height - 1)
		{
			cout << "��";
		}
		else
		{
			cout << "��";
		}
	}
	gotoxy(-1, -1);
	return;
}

void DrawManager::DrawPoint(string str, int x, int y)
{
	gotoxy(x * 2, y);
	cout << str;
	gotoxy(-1, -1);
	return;
}

void DrawManager::DrawMidText(string str, int x, int y)
{
	if (x > str.size() / 2)
	{
		x -= str.size() / 2;
	}
	gotoxy(x, y);
	cout << str;
	return;
}

void DrawManager::TextDraw(string str, int x, int y)
{
	gotoxy(x, y);
	cout << str;
}

void DrawManager::DrawBox(int Width, int Height)
{
	int width = (Width * 2) + 1;
	int height = Height + 5;
	char buf[256];
	sprintf(buf, "mode con: lines=%d cols=%d", height, width);
	system(buf);

	for (int y = 0; y < Height; y++)
	{
		gotoxy(0, y);
		if (y == 0)
		{
			cout << "��";
			for (int x = 1; x < Width - 1; x++)
			{
				cout << "��";
			}
			cout << "��";
		}
		else if (y == Height - 1)
		{
			cout << "��";
			for (int x = 1; x < Width - 1; x++)
			{
				cout << "��";
			}
			cout << "��";
		}
		else
		{
			cout << "��";
			for (int x = 1; x < Width - 1; x++)
			{
				cout << "  ";
			}
			cout << "��";
		}
	}
	return;
}

void DrawManager::DrawMap(int Width, int Height)
{
	int width = (Width * 2) + 1;
	int height = Height + 5;
	char buf[256];
	sprintf(buf, "mode con: lines=%d cols=%d", height, width);
	system(buf);

	for (int y = 0; y < Height; y++)
	{
		gotoxy(0, y);
		if (y == 0)
		{
			cout << "��";
			for (int x = 1; x < Width - 1; x++)
			{
				cout << "��";
			}
			cout << "��";
		}
		else if (y == Height - 1)
		{
			cout << "��";
			for (int x = 1; x < Width - 1; x++)
			{
				cout << "��";
			}
			cout << "��";
		}
		else
		{
			cout << "��";
			for (int x = 1; x < Width - 1; x++)
				cout << "��";
			cout << "��";
		}
	}
	return;
}


DrawManager::~DrawManager()
{
}
