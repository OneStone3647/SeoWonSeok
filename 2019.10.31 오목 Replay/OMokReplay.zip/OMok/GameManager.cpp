#include "GameManager.h"



GameManager::GameManager()
{
	m_Width = WIDTH;
	m_Height = HEIGHT;
	m_Widthptr = &m_Width;
	m_Heightptr = &m_Height;
	m_Turn = 1;
	m_bPlayState = false;

	m_Player[PLAYER_1P].SetStoneShape("��");
	m_Player[PLAYER_2P].SetStoneShape("��");
	m_Player[PLAYER_1P].SetCursorShape("��");
	m_Player[PLAYER_2P].SetCursorShape("��");
}

void GameManager::MainMenu()
{
	while (1)
	{
		int Height = m_Height / 2;
		system("cls");
		m_DrawManager.DrawMap(m_Width, m_Height);
		m_DrawManager.DrawMidText("�� �� �� ��", m_Width, Height - 6);
		m_DrawManager.DrawMidText("1.���� ����", m_Width, Height - 4);
		m_DrawManager.DrawMidText("2.Replay", m_Width, Height - 2);
		m_DrawManager.DrawMidText("3.�ɼ� ����", m_Width, Height);
		m_DrawManager.DrawMidText("4.���� ����", m_Width, Height + 2);
		m_DrawManager.DrawMidText("��������������������", m_Width, Height + 4);
		m_DrawManager.DrawMidText("��                ��", m_Width, Height + 5);
		m_DrawManager.DrawMidText("��������������������", m_Width, Height + 6);
		m_DrawManager.gotoxy(m_Width, Height + 5);
		int select;
		cin >> select;
		switch (select)
		{
		case MAINMENU_PLAY:
			Init();
			Play();
			break;
		case MAINMENU_REPLAY:
			PlayReplay();
			break;
		case MAINMENU_OPTION:
			m_Option.OptionMenu(m_Widthptr, m_Heightptr, m_bPlayState, &m_Player[PLAYER_1P], &m_Player[PLAYER_2P]);
			break;
		case MAINMENU_END:
			return;
		}
	}
}

void GameManager::Play()
{
	m_bPlayState = true;
	system("cls");
	m_DrawManager.DrawMap(m_Width, m_Height);
	DrawInputInfo();
	DrawCurrnetPlayerInfo();
	while (m_bPlayState)
	{
		m_Player[m_Turn % 2].DrawCursor();
		Input();
	}
}

void GameManager::Init()
{
	int Height = m_Height / 2;
	system("cls");
	m_Turn = 1;
	m_DrawManager.DrawBox(m_Width, m_Height);
	InitPlayer("P1 �̸�", PLAYER_1P, m_Width, Height - 3);
	InitPlayer("P2 �̸�", PLAYER_2P, m_Width, Height);
}

void GameManager::InitPlayer(string str, PLAYER player, int width, int height)
{
	m_DrawManager.DrawMidText(str, width, height);
	m_DrawManager.DrawMidText("�Է� : ", width, height + 1);
	m_Player[player].SetPlayerName();
	m_Player[player].SetPlayer(m_Width, m_Height);
}

void GameManager::DrawInputInfo()
{
	m_DrawManager.DrawMidText("====����Ű====", m_Width, m_Height);
	m_DrawManager.DrawMidText("�̵� : A,S,W,D ������ : ENTER", m_Width, m_Height + 1);
	m_DrawManager.DrawMidText("������ : N �ɼ� : P ���� : ESC", m_Width, m_Height + 2);
}

void GameManager::DrawCurrnetPlayerInfo()
{
	string tmpName = m_Player[m_Turn % 2].GetPlayerName();
	int tmpUndoCount = m_Player[m_Turn % 2].GetUndo();
	string Info = "Player Name : " + tmpName + "  ������ : " + to_string(tmpUndoCount);
	m_DrawManager.DrawMidText(Info, m_Width, m_Height + 3);
	string TurnInfo = "Turn : " + to_string(m_Turn);
	m_DrawManager.DrawMidText(TurnInfo, m_Width, m_Height + 4);
}

void GameManager::DrawCurrnetPlayerInfo(int turn, Player player)
{
	string tmpName = player.GetPlayerName();
	int tmpUndoCount = player.GetUndo();
	string Info = "Player Name : " + tmpName + "  ������ : " + to_string(tmpUndoCount);
	m_DrawManager.DrawMidText(Info, m_Width, m_Height + 3);
	string TurnInfo = "Turn : " + to_string(turn);
	m_DrawManager.DrawMidText(TurnInfo, m_Width, m_Height + 4);
}

void GameManager::Input()
{
	Point PlayerCursor;
	char key = getch();
	switch (key)
	{
	case KEY_UP:
	case KEY_LEFT:
	case KEY_DOWN:
	case KEY_RIGHT:
		ReDrawPoint();
		m_Player[m_Turn % 2].Move(key, m_Width, m_Height);
		break;
	case KEY_PUT:
		PlayerCursor = m_Player[m_Turn % 2].GetCursor();
		if (m_Player[PLAYER_1P].CheckStone(PlayerCursor.m_X, PlayerCursor.m_Y) || m_Player[PLAYER_2P].CheckStone(PlayerCursor.m_X, PlayerCursor.m_Y))
		{
			break;
		}
		m_Player[m_Turn % 2].PutStone();
		if (m_Player[m_Turn % 2].CheckVictory())
		{
			int Height = m_Height / 2;
			m_bPlayState = false;
			m_DrawManager.DrawMidText(m_Player[m_Turn % 2].GetPlayerName() + " �� �¸�", m_Width, Height);
			system("pause");
			SaveReplay();
			return;
		}
		m_Turn++;
		DrawCurrnetPlayerInfo();
		break;
	case KEY_ESC:
		m_bPlayState = false;
		break; 
	case KEY_UNDO:
		if (m_Player[m_Turn % 2].GetUndo() > 0 && m_Turn > 1)
		{
			ErasePoint();
			m_Turn--;
			m_Player[m_Turn % 2].Undo(m_Width, m_Height);
			DrawCurrnetPlayerInfo();
		}
		break;
	case KEY_OPTION:
		m_Option.OptionMenu(m_Widthptr, m_Heightptr, m_bPlayState, &m_Player[PLAYER_1P], &m_Player[PLAYER_2P]);
		system("cls");
		m_DrawManager.DrawMap(m_Width, m_Height);
		DrawInputInfo();
		DrawCurrnetPlayerInfo();
		m_Player[PLAYER_1P].DrawAllStone();
		m_Player[PLAYER_2P].DrawAllStone();
		break;
	}
}

void GameManager::ErasePoint()
{
	m_DrawManager.ErasePoint(m_Player[m_Turn % 2].GetCursor().m_X, m_Player[m_Turn % 2].GetCursor().m_Y);
	m_DrawManager.ReDrawPoint(m_Player[m_Turn % 2].GetCursor().m_X, m_Player[m_Turn % 2].GetCursor().m_Y, m_Width, m_Height);
}

void GameManager::ReDrawPoint()
{
	ErasePoint();
	m_Player[PLAYER_1P].DrawStone(m_Player[m_Turn % 2].GetCursor().m_X, m_Player[m_Turn % 2].GetCursor().m_Y);
	m_Player[PLAYER_2P].DrawStone(m_Player[m_Turn % 2].GetCursor().m_X, m_Player[m_Turn % 2].GetCursor().m_Y);
}

void GameManager::SaveReplay()
{
	ofstream save;
	save.open("Replay.text");
	if (save.is_open())
	{
		save << m_Turn << endl;
		save << m_Player[PLAYER_1P].GetPlayerName() << " " << m_Player[PLAYER_2P].GetPlayerName() << endl;
		save << m_Player[PLAYER_1P].GetStoneShape() << " " << m_Player[PLAYER_2P].GetStoneShape() << endl;
		int BiggerStoneCount = (m_Player[PLAYER_1P].GetStoneCount() > m_Player[PLAYER_2P].GetStoneCount()) ? m_Player[PLAYER_1P].GetStoneCount() : m_Player[PLAYER_2P].GetStoneCount();
		BiggerStoneCount;		
		for (int i = 0; i < BiggerStoneCount; i++)
		{
			if (i < m_Player[PLAYER_1P].GetStoneCount())
			{
				save << m_Player[PLAYER_1P].GetStoneList()[i].m_X << " " << m_Player[PLAYER_1P].GetStoneList()[i].m_Y << endl;
			}
			if (i < m_Player[PLAYER_2P].GetStoneCount())
			{
				save << m_Player[PLAYER_2P].GetStoneList()[i].m_X << " " << m_Player[PLAYER_2P].GetStoneList()[i].m_Y << endl;
			}
		}
		save.close();
	}
}

void GameManager::PlayReplay()
{
	int Height = m_Height / 2;
	ifstream load;
	int turn;
	string p1_Name;
	string p2_Name;
	string p1_StoneShape;
	string p2_StoneShape;
	int x;
	int y;
	load.open("Replay.text");
	if (load.is_open())
	{
		while (!load.eof())
		{
			system("cls");
			m_Player[PLAYER_1P].SetPlayer(m_Width, m_Height);
			m_Player[PLAYER_2P].SetPlayer(m_Width, m_Height);
			m_DrawManager.DrawMap(m_Width, m_Height);
			DrawInputInfo();
			load >> turn;
			load >> p1_Name;
			load >> p2_Name;
			load >> p1_StoneShape;
			load >> p2_StoneShape;
			m_Player[PLAYER_1P].SetPlayerName(p1_Name);
			m_Player[PLAYER_2P].SetPlayerName(p2_Name);
			m_Player[PLAYER_1P].SetStoneShape(p1_StoneShape);
			m_Player[PLAYER_2P].SetStoneShape(p2_StoneShape);
			for (int i = 1; i <= turn; i++)
			{
				load >> x;
				load >> y;
				Sleep(500);
				m_Player[i % 2].PutStone(x, y);
				DrawInputInfo();
				DrawCurrnetPlayerInfo(i, m_Player[i % 2]);
				if (m_Player[i % 2].CheckVictory())
				{
					Sleep(1000);
					m_DrawManager.DrawMidText(m_Player[i % 2].GetPlayerName() + " �� �¸�", m_Width, Height);
					system("pause");
					return;
				}
			}
		}
	}
	else
	{
		system("cls");
		m_DrawManager.DrawBox(m_Width, m_Height);
		m_DrawManager.DrawMidText("����� ����� �����ϴ�.", m_Width, Height);
		system("pause");
	}
}


GameManager::~GameManager()
{
}
