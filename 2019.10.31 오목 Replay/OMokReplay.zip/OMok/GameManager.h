#pragma once
#include "Player.h"
#include "Option.h"

enum MAINMENU
{
	MAINMENU_PLAY = 1,
	MAINMENU_REPLAY,
	MAINMENU_OPTION,
	MAINMENU_END
};

class GameManager
{
private:
	int m_Width;
	int m_Height;
	int* m_Widthptr;
	int* m_Heightptr;
	int m_Turn;
	bool m_bPlayState;
	DrawManager m_DrawManager;
	Option m_Option;
	Player m_Player[PLAYER_END];
public:
	GameManager();
	void MainMenu();
	void Play();
	void Init();
	void InitPlayer(string str, PLAYER player, int width, int height);
	void DrawInputInfo();
	void DrawCurrnetPlayerInfo();
	void DrawCurrnetPlayerInfo(int turn, Player player);
	void Input();
	void ErasePoint();
	void ReDrawPoint();
	void SaveReplay();
	void PlayReplay();
	~GameManager();
};

