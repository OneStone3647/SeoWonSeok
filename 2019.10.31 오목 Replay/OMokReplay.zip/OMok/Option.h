#pragma once
#include "DrawManager.h"
#include "Player.h"

enum OPTIONMENU
{
	OPTIONMENU_MAPSIZESET = 1,
	OPTIONMENU_CURSORCUSTOM,
	OPTIONMENU_STONECUSTOM,
	OPTIONMENU_UNDOCOUNTSET,
	OPTIONMENU_RETURN
};

class Option
{
private:
	int m_Width;
	int m_Height;
	DrawManager m_DrawManager;
	Player m_Player;
public:
	Option();
	void OptionMenu(int* width, int* height, bool bPlayState, Player* player1P, Player* player2P);
	void MapSizeSet(int* width, int* height, bool bPlayState);
	void CursorCustom(Player* player1P, Player* player2P);
	void StoneCustom(Player* player1P, Player* player2P);
	void UndoCountSet(Player* player1P, Player* player2P, bool bPlayState);
	~Option();
};

