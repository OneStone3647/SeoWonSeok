#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <conio.h>
#include <iomanip>
#include <Windows.h>
#include <time.h>

using namespace std;

#define WIDTH 20
#define HEIGHT 20