#include "Character.h"



Character::Character()
{
	m_Character = "��";
	m_X = 0;
	m_Y = 0;
}

void Character::DrawCharacter(int mapX, int mapY, int width, int height)
{
	m_CharacterX = mapX + m_X;									// 0
	m_CharacterY = mapY + (height / 2) + m_Y;		// 0
	m_DrawManager.DrawPoint(m_Character, m_CharacterX, m_CharacterY);
	MoveCharacter(mapX, mapY, width, height);
	m_DrawManager.ErasePoint(m_CharacterX, m_CharacterY);
}

void Character::MoveCharacter(int mapX, int mapY, int width, int height)
{
	char move = getch();
	switch (move)
	{
	case 'w':
		if (m_CharacterY > mapY + 1)
		{
			m_Y--;
		}
		break;
	case 's':
		if (m_CharacterY < mapY + height -2)
		{
			m_Y++;
		}
		break;
	case 'a':
		if (m_X > -mapX + width / 2 + 1)
		{
			m_X--;
		}
		break;
	case 'd':
		if (m_X < width / 2 - 2)
		{
			m_X++;
		}
		break;
	}
}

Character::~Character()
{
}
