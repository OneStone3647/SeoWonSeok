#pragma once
#include "MapDraw.h"

class Character
{
private:	
	string m_Character;
	int m_X;
	int m_Y;
	int m_CharacterX;
	int m_CharacterY;
	MapDraw m_DrawManager;
public:
	Character();
	void DrawCharacter(int mapX, int mapY, int width, int height);
	void MoveCharacter(int mapX, int mapY, int width, int height);
	~Character();
};

