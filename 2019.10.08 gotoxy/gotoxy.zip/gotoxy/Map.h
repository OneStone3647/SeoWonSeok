#pragma once
#include "Mecro.h"
#include "Character.h"

class Map
{
private:
	int m_x;
	int m_y;
	int m_Width;
	int m_Height;
	MapDraw m_DrawManager;
	Character C;
public:
	Map();
	void MapDraw();
	void Update();
	~Map();
};

