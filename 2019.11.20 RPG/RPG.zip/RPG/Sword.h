#pragma once
#include "Weapon.h"

class Sword : public Weapon
{
public:
	Sword();
	Sword(const Weapon& weapon);
	virtual void Ability(Character* caster, Character* target, int x, int y);
	~Sword();
};

