#pragma once
#include "Weapon.h"

class Bow : public Weapon
{
public:
	Bow();
	Bow(const Weapon& weapon);
	virtual void Ability(Character* caster, Character* target, int x, int y);
	~Bow();
};

