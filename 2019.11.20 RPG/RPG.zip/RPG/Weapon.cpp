#include "Weapon.h"

MapDraw Weapon::m_MapDraw;

Weapon::Weapon()
{
}

Weapon::Weapon(const Weapon & weapon)
{
	m_Type = weapon.m_Type;
	m_Name = weapon.m_Name;
	m_Att = weapon.m_Att;
	m_Price = weapon.m_Price;
}

void Weapon::SetWeaponInfo(string type, string name, int att, int price)
{
	m_Type = type;
	m_Name = name;
	m_Att = att;
	m_Price = price;
}

void Weapon::ShowWeaponShopInfo(int x, int y)
{
	m_MapDraw.DrawMidText("���� : " + to_string(m_Price) + " ����Ÿ�� : " + m_Type, x, y);
	m_MapDraw.DrawMidText("�����̸� : " + m_Name + " ���ݷ� : " + to_string(m_Att), x, y + 1);
}

void Weapon::ShowWeaponInfo(int x, int y)
{
	m_MapDraw.DrawMidText("����Ÿ�� : " + m_Type + " �����̸� : " + m_Name, x, y);
}


Weapon::~Weapon()
{
}
