#pragma once
#include "Weapon.h"

class Wand : public Weapon
{
public:
	Wand();
	Wand(const Weapon& weapon);
	virtual void Ability(Character* caster, Character* target, int x, int y);
	~Wand();
};

