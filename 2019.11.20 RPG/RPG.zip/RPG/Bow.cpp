#include "Bow.h"



Bow::Bow()
{
}

Bow::Bow(const Weapon & weapon)
	:Weapon(weapon)
{
}

void Bow::Ability(Character * caster, Character * target, int x, int y)
{
	srand((unsigned int)time(NULL));
	int percent = rand() % 100 + 1;		// 1 ~ 100 ������ ����
	int Damage = caster->GetCharacterAtt() + this->GetWeaponAtt();
	if (percent <= 40)
	{
		m_MapDraw.DrawMidText("���� �� �ߵ�!!<Damage: " + to_string(Damage) + ">", x, y);
		target->SetDamage(Damage);
	}
}


Bow::~Bow()
{
}
