#pragma once
#include "Weapon.h"

class Dagger : public Weapon
{
public:
	Dagger();
	Dagger(const Weapon& weapon);
	virtual void Ability(Character* caster, Character* target, int x, int y);
	~Dagger();
};

