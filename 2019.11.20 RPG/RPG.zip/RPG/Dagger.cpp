#include "Dagger.h"



Dagger::Dagger()
{
}

Dagger::Dagger(const Weapon & weapon)
	:Weapon(weapon)
{
}

void Dagger::Ability(Character * caster, Character * target, int x, int y)
{
	srand((unsigned int)time(NULL));
	int percent = rand() % 100 + 1;		// 1 ~ 100 ������ ����
	int Damage = caster->GetCharacterAtt() + this->GetWeaponAtt();
	if (percent <= 10)
	{
		m_MapDraw.DrawMidText("���� ���� �ߵ�!!<Damage: " + to_string(Damage) + ">", x, y);
		target->SetDamage(Damage);
	}
}


Dagger::~Dagger()
{
}
