#pragma once
#include "Weapon.h"
#include "MapDraw.h"
#include "Player.h"

enum SHOPLIST
{
	SHOPLIST_GAUNTLET = 1,
	SHOPLIST_GUN,
	SHOPLIST_SWORD,
	SHOPLIST_WAND,
	SHOPLIST_BOW,
	SHOPLIST_HAMMER,
	SHOPLIST_DAGGER,
	SHOPLIST_EXIT
};

class WeaponShop
{
private:
	int m_X;
	int m_Y;
	MapDraw m_MapDraw;
	Weapon** m_Weapon;
	int m_WeaponCount;
public:
	WeaponShop();
	void ShopMenu(Player* player);
	bool CheckWeaponListFile();
	void SetWeaponList();
	void ShowWeaponList(Player* player, string weaponType);
	~WeaponShop();
};

