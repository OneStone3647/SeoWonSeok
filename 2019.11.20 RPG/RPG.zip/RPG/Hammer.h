#pragma once
#include "Weapon.h"

class Hammer : public Weapon
{
public:
	Hammer();
	Hammer(const Weapon& weapon);
	virtual void Ability(Character* caster, Character* target, int x, int y);
	~Hammer();
};

