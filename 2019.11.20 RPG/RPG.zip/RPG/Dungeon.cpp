#include "Dungeon.h"



Dungeon::Dungeon()
{
	m_X = WIDTH / 2;
	m_Y = HEIGHT / 2;
}

void Dungeon::DungeonMenu(bool * bIsPlay, Player * player, Monster * monster, int monsterCount)
{
	m_Player = player;
	m_Monster = monster;
	m_MonsterCount = monsterCount;
	m_bIsPlay = bIsPlay;
	while (*m_bIsPlay)
	{
		m_MapDraw.BoxErase(WIDTH, HEIGHT);
		ORIGINAL;
		m_MapDraw.DrawMidText("=====���� �Ա�=====", WIDTH, m_Y - 8);
		for (int i = 0; i < m_MonsterCount + 1; i++)
		{
			if (i == m_MonsterCount)
			{
				m_MapDraw.DrawMidText("���ư���", WIDTH, m_Y + 2 * i - 4);
			}
			else
			{
				m_MapDraw.DrawMidText(to_string(i + 1) + "������ : [" + m_Monster[i].GetCharacterName() + "]", WIDTH, m_Y + 2 * i - 4);
			}
		}
		switch (m_MapDraw.MenuSelectCursor(m_MonsterCount + 1, 2, m_X - 8, m_Y - 4))
		{
		case DUNGEONFLOOR_FRIST:
			Combat(&m_Monster[0]);
			break;
		case DUNGEONFLOOR_SECOND:
			Combat(&m_Monster[1]);
			break;
		case DUNGEONFLOOR_THIRD:
			Combat(&m_Monster[2]);
			break;
		case DUNGEONFLOOR_FOURTH:
			Combat(&m_Monster[3]);
			break;
		case DUNGEONFLOOR_FIVETH:
			Combat(&m_Monster[4]);
			break;
		case DUNGEONFLOOR_SIXTH:
			Combat(&m_Monster[5]);
		default:
			return;
		}
	}
}

void Dungeon::Combat(Monster * monster)
{
	char playerSelect;
	char monsterSelect;
	DrawCombatInfo(monster);
	while (1)
	{
		playerSelect = m_Player->SelectAttack();
		monsterSelect = monster->SelectAttack();
		if (CheckWinner(monster))
		{
			return;
		}
		if (playerSelect == SELECT_SCISSORS || playerSelect == SELECT_ROCK || playerSelect == SELECT_PAPER)
		{
			DrawCombatInfo(monster);
			ShowAttackSelect(playerSelect, monsterSelect);
			if (playerSelect == monsterSelect)
			{
				RED;
				m_MapDraw.DrawMidText("Draw", WIDTH, m_Y - 2);
				m_MapDraw.DrawMidText("Draw", WIDTH, m_Y + 2);
			}
			else if (playerSelect > monsterSelect)
			{
				if (monsterSelect == SELECT_SCISSORS && playerSelect == SELECT_PAPER)
				{
					RED;
					m_MapDraw.DrawMidText("Lose", WIDTH, m_Y - 2);
					m_MapDraw.DrawMidText("Win", WIDTH, m_Y + 2);
					m_Player->SetDamage(monster->GetCharacterAtt());
				}
				else
				{
					RED;
					m_MapDraw.DrawMidText("Win", WIDTH, m_Y - 2);
					m_MapDraw.DrawMidText("Lose", WIDTH, m_Y + 2);
					if (m_Player->GetPlayerHaveWeapon() == true)
					{
						monster->SetDamage(m_Player->GetCharacterAtt() + m_Player->GetPlayerWeapon()->GetWeaponAtt());
						m_Player->GetPlayerWeapon()->Ability(m_Player, monster, WIDTH, m_Y - 1);
					}
					else
					{
						monster->SetDamage(m_Player->GetCharacterAtt());
					}
				}
			}
			else
			{
				if (playerSelect == SELECT_SCISSORS && monsterSelect == SELECT_PAPER)
				{
					RED;
					m_MapDraw.DrawMidText("Win", WIDTH, m_Y - 2);
					m_MapDraw.DrawMidText("Lose", WIDTH, m_Y + 2);
					if (m_Player->GetPlayerHaveWeapon() == true)
					{
						monster->SetDamage(m_Player->GetCharacterAtt() + m_Player->GetPlayerWeapon()->GetWeaponAtt());
						m_Player->GetPlayerWeapon()->Ability(m_Player, monster, WIDTH, m_Y - 1);
					}
					else
					{
						monster->SetDamage(m_Player->GetCharacterAtt());
					}
				}
				else
				{
					RED;
					m_MapDraw.DrawMidText("Lose", WIDTH, m_Y - 2);
					m_MapDraw.DrawMidText("Win", WIDTH, m_Y + 2);
					m_Player->SetDamage(monster->GetCharacterAtt());
				}
			}
		}
	}
}

void Dungeon::DrawCombatInfo(Monster * monster)
{
	m_MapDraw.BoxErase(WIDTH, HEIGHT);
	YELLOW;
	m_Player->ShowPlayerInfo(WIDTH, m_Y - 11);
	ORIGINAL;
	m_MapDraw.DrawMidText("���� : 1    ���� : 2    �� : 3", WIDTH, m_Y - 5);
	monster->ShowCharacterInfo(WIDTH, m_Y + 7);
	RED;
	m_MapDraw.DrawMidText("-------------------------- vs --------------------------", WIDTH, m_Y);
}

void Dungeon::ShowAttackSelect(char playerSelect, char monsterSelect)
{
	YELLOW;
	switch (playerSelect)
	{
	case SELECT_SCISSORS:
		m_MapDraw.DrawMidText("����", WIDTH, m_Y - 3);
		break;
	case SELECT_ROCK:
		m_MapDraw.DrawMidText("����", WIDTH, m_Y - 3);
		break;
	case SELECT_PAPER:
		m_MapDraw.DrawMidText("��", WIDTH, m_Y - 3);
		break;
	}
	ORIGINAL;
	switch (monsterSelect)
	{
	case SELECT_SCISSORS:
		m_MapDraw.DrawMidText("����", WIDTH, m_Y + 3);
		break;
	case SELECT_ROCK:
		m_MapDraw.DrawMidText("����", WIDTH, m_Y + 3);
		break;
	case SELECT_PAPER:
		m_MapDraw.DrawMidText("��", WIDTH, m_Y + 3);
		break;
	}
}

bool Dungeon::CheckWinner(Monster * monster)
{
	if (monster->IsDead())
	{
		m_MapDraw.BoxErase(WIDTH, HEIGHT);
		RED;
		m_MapDraw.DrawMidText(m_Player->GetCharacterName() + " �¸�", WIDTH, m_Y - 6);
		m_MapDraw.DrawMidText(m_Player->GetCharacterName() + "�� ����ġ " + to_string(monster->GetCharacterGetExp()) +
			"�� ������ϴ�.", WIDTH, m_Y - 4);
		monster->SetCharacterCurHP(monster->GetCharacterMaxHP());		// ���� ü��ȸ��
		m_Player->SetCharacterCurHP(m_Player->GetCharacterMaxHP());		// �÷��̾� ü��ȸ��
		m_Player->SetCharacterExp(monster->GetCharacterGetExp());
		m_Player->SetHaveGold(monster->GetCharacterHaveGold());
		if (m_Player->GetCharacterCurExp() >= m_Player->GetCharacterMaxExp())		// ������
		{
			getch();
			m_Player->LevelUp();
			m_MapDraw.BoxErase(WIDTH, HEIGHT);
			PUPPLE;
			m_MapDraw.DrawMidText(m_Player->GetCharacterName() + "������!!", WIDTH, m_Y - 4);
			if (m_Player->GetCharacterLevel() % 2 == 0)
			{
				m_MapDraw.DrawMidText("���ݷ� 4 ����!!", WIDTH, m_Y - 1);
				m_MapDraw.DrawMidText("������ 0 ����!!", WIDTH, m_Y + 2);
			}
			else
			{
				m_MapDraw.DrawMidText("���ݷ� 0 ����!!", WIDTH, m_Y - 1);
				m_MapDraw.DrawMidText("������ 7 ����!!", WIDTH, m_Y + 2);
			}
		}
		getch();
		return true;
	}
	if (m_Player->IsDead())
	{
		m_MapDraw.BoxErase(WIDTH, HEIGHT);
		RED;
		m_MapDraw.DrawMidText(monster->GetCharacterName() + " �¸�", WIDTH, m_Y - 6);
		m_MapDraw.DrawMidText(monster->GetCharacterName() + "�� ����ġ " + to_string(m_Player->GetCharacterGetExp()) +
			"�� ������ϴ�.", WIDTH, m_Y - 4);
		getch();
		m_MapDraw.DrawMidText("YOU DIED", WIDTH, m_Y);
		*m_bIsPlay = false;
		getch();
		return true;
	}
	return false;
}

Dungeon::~Dungeon()
{
}
