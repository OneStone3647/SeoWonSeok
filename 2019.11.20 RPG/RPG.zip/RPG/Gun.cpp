#include "Gun.h"



Gun::Gun()
{
}

Gun::Gun(const Weapon & weapon)
	:Weapon(weapon)
{
}

void Gun::Ability(Character * caster, Character * target, int x, int y)
{
	srand((unsigned int)time(NULL));
	int percent = rand() % 100 + 1;		// 1 ~ 100 ������ ����
	int Damage = target->GetCharacterCurHP() / 2;
	if (percent <= 10)
	{
		m_MapDraw.DrawMidText("��弦 �ߵ�!!<Damage: " + to_string(Damage) + ">", x, y);
		target->SetDamage(Damage);
	}
}


Gun::~Gun()
{
}
