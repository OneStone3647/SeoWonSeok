#include "Hammer.h"



Hammer::Hammer()
{
}

Hammer::Hammer(const Weapon & weapon)
	:Weapon(weapon)
{
}

void Hammer::Ability(Character * caster, Character * target, int x, int y)
{
	srand((unsigned int)time(NULL));
	int percent = rand() % 100 + 1;		// 1 ~ 100 ������ ����
	int att = caster->GetCharacterAtt() / 2;
	if (percent <= 40)
	{
		m_MapDraw.DrawMidText("��ũ�� �ߵ�!!<Player�� ���ݷ� " + to_string(att) + " ���!!>", x, y);
		caster->IncreaseAtt(att);
	}
}


Hammer::~Hammer()
{
}
