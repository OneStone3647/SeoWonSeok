#include "GameManager.h"



GameManager::GameManager()
{
	m_X = WIDTH / 2;
	m_Y = HEIGHT / 2;
	m_Player = NULL;
	m_Monster = NULL;
	m_bIsPlay = true;
	m_bIsPlayptr = &m_bIsPlay;
}

void GameManager::MainMenu()
{
	char key;
	while (1)
	{
		BLUE;
		m_MapDraw.BoxDraw(0, 0, WIDTH, HEIGHT);
		ORIGINAL;
		m_MapDraw.DrawMidText("�١� DonGeonRPG �ڡ�", WIDTH, m_Y - 3);
		m_MapDraw.DrawMidText("New Game", WIDTH, m_Y);
		m_MapDraw.DrawMidText("Load Game", WIDTH, m_Y + 3);
		m_MapDraw.DrawMidText("Game Exit", WIDTH, m_Y + 6);
		switch (m_MapDraw.MenuSelectCursor(3, 3, m_X - 4, m_Y))
		{
		case MAINMENU_NEWGAME:
			if (CheckDefaultPlayerFile() && CheckDefaultMonsterFile())		// �÷��̾�, ���� ���� üũ
			{
				m_bIsPlay = true;
				GameMenu();
			}
			break;
		case MAINMENU_LOADGAME:
			if (Load())
			{
				GameMenu();
			}
			break;
		case MAINMENU_GAMEEXIT:
			return;
		}
	}
}

void GameManager::GameMenu()
{
	while (m_bIsPlay)
	{
		m_MapDraw.BoxErase(WIDTH, HEIGHT);
		ORIGINAL;
		m_MapDraw.DrawMidText("�١� Menu �ڡ�", WIDTH, m_Y - 6);
		m_MapDraw.DrawMidText("Dongeon", WIDTH, m_Y - 4);
		m_MapDraw.DrawMidText("Player Info", WIDTH, m_Y - 2);
		m_MapDraw.DrawMidText("Monster Info", WIDTH, m_Y);
		m_MapDraw.DrawMidText("Weapon Shop", WIDTH, m_Y + 2);
		m_MapDraw.DrawMidText("Save", WIDTH, m_Y + 4);
		m_MapDraw.DrawMidText("Exit", WIDTH, m_Y + 6);
		switch (m_MapDraw.MenuSelectCursor(6, 2, m_X - 6, m_Y - 4))
		{
		case GAMEMENU_DONGEON:
			m_Dungeon.DungeonMenu(m_bIsPlayptr, m_Player, m_Monster, m_MonsterCount);
			break;
		case GAMEMENU_PLAYERINFO:
			ShowPlayerInfo();
			break;
		case GAMEMENU_MONSTERINFO:
			ShowMonsterInfo();
			break;
		case GAMEMENU_WEAPONSHOP:
			m_WeaponShop.ShopMenu(m_Player);
			break;
		case GAMEMENU_SAVE:
			Save();
			break;
		case GAMEMENU_EXIT:
			Release();
			return;
		}
	}
	// �÷��̾� ��� �� �����Ҵ� ����
	if (m_bIsPlay == false)
	{
		Release();
	}
}

bool GameManager::CheckDefaultPlayerFile()		// �÷��̾� ����Ʈ ���� üũ �� �ҷ�����
{
	int att;
	int maxHp;
	int maxExp;
	int getExp;
	int level;
	int haveGold;
	ifstream load;
	load.open("DefaultPlayer.txt");
	if (load.is_open())
	{
		m_Player = new Player;
		while (!load.eof())
		{
			load >> att;
			load >> maxHp;
			load >> maxExp;
			load >> getExp;
			load >> level;
			load >> haveGold;
			m_Player->SetChracterDefaultInfo(SetPlayerName(), att, maxHp, maxExp, getExp, level, haveGold);
			return true;
		}
	}
	else
	{
		m_MapDraw.BoxErase(WIDTH, HEIGHT);
		ORIGINAL;
		m_MapDraw.DrawMidText("Player���� ����", WIDTH, m_Y);
		getch();
		return false;
	}
}

bool GameManager::CheckDefaultMonsterFile()		// ���� ����Ʈ ���� üũ �� �ҷ�����
{
	string name;
	int att;
	int maxHp;
	int maxExp;
	int getExp;
	int level;
	int haveGold;
	ifstream load;
	load.open("DefaultMonster.txt");
	if (load.is_open())
	{
		while (!load.eof())
		{
			load >> m_MonsterCount;
			m_Monster = new Monster[m_MonsterCount];
			for (int i = 0; i < m_MonsterCount; i++)
			{
				load >> name;
				load >> att;
				load >> maxHp;
				load >> maxExp;
				load >> getExp;
				load >> level;
				load >> haveGold;
				m_Monster[i].SetChracterDefaultInfo(name, att, maxHp, maxExp, getExp, level, haveGold);
			}
			return true;
		}
	}
	else
	{
		m_MapDraw.BoxErase(WIDTH, HEIGHT);
		ORIGINAL;
		m_MapDraw.DrawMidText("Monster���� ����", WIDTH, m_Y);
		getch();
		return false;
	}
}

string GameManager::SetPlayerName()
{
	string tmp;
	m_MapDraw.BoxErase(WIDTH, HEIGHT);
	YELLOW;
	m_MapDraw.DrawMidText("Player �̸� �Է� : ", WIDTH, m_Y);
	cin >> tmp;
	ORIGINAL;
	return tmp;
}

void GameManager::Release()
{
	delete m_Player;
	delete[] m_Monster;
}

void GameManager::ShowPlayerInfo()
{
	m_MapDraw.BoxErase(WIDTH, HEIGHT);
	YELLOW;
	m_Player->ShowPlayerInfo(WIDTH, m_Y);
	ORIGINAL;
	getch();
}

void GameManager::ShowMonsterInfo()
{
	m_MapDraw.BoxErase(WIDTH, HEIGHT);
	ORIGINAL;
	int height = 0;
	for (int i = 0; i < m_MonsterCount; i++)
	{
		height = 4 * i + 3;
		m_Monster[i].ShowCharacterInfo(WIDTH, height);
	}
	getch();
}

void GameManager::DrawSaveSlot()
{
	for (int i = 0; i < SAVESLOTCOUNT + 1; i++)
	{
		int height = 2 * (i + 2) + 1;
		int count = i + 1;
		if (i == SAVESLOTCOUNT)
		{
			m_MapDraw.TextDraw(to_string(count) + "���ư���", m_X + 3, height);
		}
		else if (CheckSavePlayerFile(i) && CheckSaveMonsterFile(i))
		{
			m_MapDraw.DrawMidText(to_string(count) + "������ : (���Ͽ��� : O)", WIDTH, height);
		}
		else
		{
			m_MapDraw.DrawMidText(to_string(count) + "������ : (���Ͽ��� : X)", WIDTH, height);
		}
	}
}

bool GameManager::CheckSavePlayerFile(int slotCount)
{
	char fileName[20];
	ifstream load;
	sprintf(fileName, "SavePlayer%d.txt", slotCount + 1);
	load.open(fileName);
	if (load.is_open())
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool GameManager::CheckSaveMonsterFile(int slotCount)
{
	char fileName[20];
	ifstream load;
	sprintf(fileName, "SaveMonster%d.txt", slotCount + 1);
	load.open(fileName);
	if (load.is_open())
	{
		return true;
	}
	else
	{
		return false;
	}
}

void GameManager::Save()
{
	m_MapDraw.BoxErase(WIDTH, HEIGHT);
	GREEN;
	DrawSaveSlot();
	int saveSlot = m_MapDraw.MenuSelectCursor(11, 2, m_X - 8, m_Y - 10);
	if (saveSlot != SAVESLOTCOUNT + 1)		// 1 ~ 10�� ����
	{
		SavePlayerFile(saveSlot);
		SaveMonsterFile(saveSlot);
		m_MapDraw.BoxErase(WIDTH, HEIGHT);
		ORIGINAL;
		m_MapDraw.DrawMidText("Save �Ϸ�", WIDTH, m_Y);
		getch();
	}
}

void GameManager::SavePlayerFile(int slotCount)
{
	char fileName[20];
	ofstream save;
	sprintf(fileName, "SavePlayer%d.txt", slotCount);
	save.open(fileName);
	if (save.is_open())
	{
		save << m_Player->GetCharacterName() << " ";
		save << m_Player->GetCharacterAtt() << " ";
		save << m_Player->GetCharacterMaxHP() << " ";
		save << m_Player->GetCharacterMaxExp() << " ";
		save << m_Player->GetCharacterGetExp() << " ";
		save << m_Player->GetCharacterLevel() << " ";
		save << m_Player->GetCharacterHaveGold() << " ";
		save << m_Player->GetCharacterCurExp() << " ";
		save << m_Player->GetCharacterCurHP() << endl;
		if (m_Player->GetPlayerHaveWeapon() == true)
		{
			save << HAVEWEPAON_TRUE;
			save << m_Player->GetPlayerWeapon()->GetWeaponType() << " ";
			save << m_Player->GetPlayerWeapon()->GetWeaponName() << " ";
			save << m_Player->GetPlayerWeapon()->GetWeaponAtt() << " ";
			save << m_Player->GetPlayerWeapon()->GetWeaponPrice();
		}
		else
		{
			save << HAVEWEAPON_FALSE;
		}
		save.close();
	}
}

void GameManager::SaveMonsterFile(int slotCount)
{
	char fileName[20];
	ofstream save;
	sprintf(fileName, "SaveMonster%d.txt", slotCount);
	save.open(fileName);
	if (save.is_open())
	{
		save << m_MonsterCount;
		for (int i = 0; i < m_MonsterCount; i++)
		{
			save << endl << m_Monster[i].GetCharacterName() << " ";
			save << m_Monster[i].GetCharacterAtt() << " ";
			save << m_Monster[i].GetCharacterMaxHP() << " ";
			save << m_Monster[i].GetCharacterMaxExp() << " ";
			save << m_Monster[i].GetCharacterGetExp() << " ";
			save << m_Monster[i].GetCharacterLevel() << " ";
			save << m_Monster[i].GetCharacterHaveGold() << " ";
			save << m_Monster[i].GetCharacterCurExp() << " ";
			save << m_Monster[i].GetCharacterCurHP();
		}
		save.close();
	}
}

bool GameManager::Load()
{
	while (1)
	{
		m_MapDraw.BoxErase(WIDTH, HEIGHT);
		GREEN;
		DrawSaveSlot();
		int saveSlot = m_MapDraw.MenuSelectCursor(11, 2, m_X - 8, m_Y - 10);
		if (saveSlot != SAVESLOTCOUNT + 1)		// 1 ~ 10�� ����
		{
			if (LoadPlayerFile(saveSlot) && LoadMonsterFile(saveSlot))
			{
				m_MapDraw.BoxErase(WIDTH, HEIGHT);
				ORIGINAL;
				m_MapDraw.DrawMidText("Load �Ϸ�", WIDTH, m_Y);
				getch();
				return true;
			}
			else
			{
				m_MapDraw.BoxErase(WIDTH, HEIGHT);
				ORIGINAL;
				m_MapDraw.DrawMidText("�ش� ������ �����ϴ�.", WIDTH, m_Y);
				system("pause");
			}
		}
		else
		{
			return false;
		}
	}
}

bool GameManager::LoadPlayerFile(int slotCount)
{
	char fileName[20];
	ifstream load;
	sprintf(fileName, "SavePlayer%d.txt", slotCount);
	load.open(fileName);
	if (load.is_open())
	{
		m_Player = new Player;
		string name;
		int att;
		int maxHP;
		int maxExp;
		int getExp;
		int level;
		int haveGold;
		int curExp;
		int curHP;
		string tmp;
		bool haveWeapon;
		int weaponCount;
		string weaponType;
		string weaponName;
		int weaponAtt;
		int weaponPrice;
		while (!load.eof())
		{
			load >> name;
			load >> att;
			load >> maxHP;
			load >> maxExp;
			load >> getExp;
			load >> level;
			load >> haveGold;
			load >> curExp;
			load >> curHP;
			load >> tmp;
			// ���⸦ ���� ��
			if (tmp.substr(0, 1) == "1")
			{
				haveWeapon = HAVEWEPAON_TRUE;
				weaponType = tmp.erase(0, 1);
				load >> weaponName;
				load >> weaponAtt;
				load >> weaponPrice;
			}
			else
			{
				haveWeapon = HAVEWEAPON_FALSE;
				break;
			}
		}
		m_Player->SetCharacterInfo(name, att, maxHP, maxExp, getExp, level, haveGold, curExp, curHP);
		m_Player->SetPlayerHaveWeapon(haveWeapon);
		if (haveWeapon == true)
		{
			Weapon* tmp = NULL;
			if (weaponType == "Bow")
			{
				tmp = new Bow;
			}
			else if (weaponType == "Dagger")
			{
				tmp = new Dagger;
			}
			else if (weaponType == "Gun")
			{
				tmp = new Gun;
			}
			else if (weaponType == "Hammer")
			{
				tmp = new Hammer;
			}
			else if (weaponType == "Sword")
			{
				tmp = new Sword;
			}
			else if (weaponType == "Wand")
			{
				tmp = new Wand;
			}
			else if (weaponType == "Gauntlet")
			{
				tmp = new Gauntlet;
			}
			tmp->SetWeaponInfo(weaponType, weaponName, weaponAtt, weaponPrice);
			m_Player->SetWeapon(tmp);
			delete tmp;
		}
		return true;
	}
	else
	{
		return false;
	}
}

bool GameManager::LoadMonsterFile(int slotCount)
{
	char fileName[20];
	ifstream load;
	sprintf(fileName, "SaveMonster%d.txt", slotCount);
	load.open(fileName);
	if (load.is_open())
	{
		string name;
		int att;
		int maxHP;
		int maxExp;
		int getExp;
		int level;
		int haveGold;
		int curExp;
		int curHP;
		while (!load.eof())
		{
			load >> m_MonsterCount;
			m_Monster = new Monster[m_MonsterCount];
			for (int i = 0; i < m_MonsterCount; i++)
			{
				load >> name;
				load >> att;
				load >> maxHP;
				load >> maxExp;
				load >> getExp;
				load >> level;
				load >> haveGold;
				load >> curExp;
				load >> curHP;
				m_Monster[i].SetCharacterInfo(name, att, maxHP, maxExp, getExp, level, haveGold, curExp, curHP);
			}
		}
		return true;
	}
	else
	{
		return false;
	}
}


GameManager::~GameManager()
{
}
