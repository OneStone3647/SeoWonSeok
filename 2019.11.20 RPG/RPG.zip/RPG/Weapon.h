#pragma once
#include "MapDraw.h"
#include "Character.h"

class Weapon
{
protected:
	static MapDraw m_MapDraw;
	// ĳ���� ����
protected:
	string m_Type;
	string m_Name;
	int m_Att;
	int m_Price;
public:
	Weapon();
	Weapon(const Weapon& weapon);
	void SetWeaponInfo(string type, string name, int att, int price);
	void ShowWeaponShopInfo(int x, int y);
	void ShowWeaponInfo(int x, int y);
	virtual void Ability(Character* caster, Character* target, int x, int y) = 0;
	inline string GetWeaponType()
	{
		return m_Type;
	}
	inline string GetWeaponName()
	{
		return m_Name;
	}
	inline int GetWeaponAtt()
	{
		return m_Att;
	}
	inline int GetWeaponPrice()
	{
		return m_Price;
	}
	virtual ~Weapon();
};

