#pragma once
#include "Character.h"

class Monster : public Character
{
public:
	Monster();
	inline char SelectAttack()
	{
		srand((unsigned int)time(NULL));
		return (rand() % 3) + 49;
	}
	~Monster();
};

