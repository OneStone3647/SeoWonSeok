#pragma once
#include "Character.h"
#include "Bow.h"
#include "Dagger.h"
#include "Gun.h"
#include "Hammer.h"
#include "Sword.h"
#include "Wand.h"
#include "Gauntlet.h"

enum HAVEWEAPON
{
	HAVEWEAPON_FALSE = 0,
	HAVEWEPAON_TRUE
};

class Player : public Character
{
private:
	bool m_HaveWeapon;
	Weapon* m_Weapon;
public:
	Player();
	void SetWeapon(Weapon* weapon);
	void ShowPlayerInfo(int x, int y);
	inline char SelectAttack()
	{
		return getch();
	}
	inline Weapon* GetPlayerWeapon()
	{
		return m_Weapon;
	}
	inline void SetPlayerHaveWeapon(bool flag)
	{
		m_HaveWeapon = flag;
	}
	inline void DecreaseHaveGold(int gold)
	{
		m_HaveGold -= gold;
	}
	inline bool GetPlayerHaveWeapon()
	{
		return m_HaveWeapon;
	}
	~Player();
};

