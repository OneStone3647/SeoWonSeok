#pragma once
#include "Weapon.h"

class Gauntlet : public Weapon
{
public:
	Gauntlet();
	Gauntlet(const Weapon& weapon);
	virtual void Ability(Character* caster, Character* target, int x, int y);
	~Gauntlet();
};

