#pragma once
#include "MapDraw.h"
#include "Player.h"
#include "Monster.h"
#include "Dungeon.h"
#include "WeaponShop.h"

#define SAVESLOTCOUNT 10

enum MAINMENU
{
	MAINMENU_NEWGAME = 1,
	MAINMENU_LOADGAME,
	MAINMENU_GAMEEXIT
};

enum GAMEMENU
{
	GAMEMENU_DONGEON = 1,
	GAMEMENU_PLAYERINFO,
	GAMEMENU_MONSTERINFO,
	GAMEMENU_WEAPONSHOP,
	GAMEMENU_SAVE,
	GAMEMENU_EXIT
};

class GameManager
{
private:
	MapDraw m_MapDraw;
	int m_X;
	int m_Y;
	Player* m_Player;
	Monster* m_Monster;
	int m_MonsterCount;
	Dungeon m_Dungeon;
	WeaponShop m_WeaponShop;
	bool m_bIsPlay;
	bool* m_bIsPlayptr;
public:
	GameManager();
	void MainMenu();
	void GameMenu();
	bool CheckDefaultPlayerFile();
	bool CheckDefaultMonsterFile();
	string SetPlayerName();
	void Release();
	void ShowPlayerInfo();
	void ShowMonsterInfo();
	void DrawSaveSlot();
	bool CheckSavePlayerFile(int slotCount);
	bool CheckSaveMonsterFile(int slotCount);
	void Save();
	void SavePlayerFile(int slotCount);
	void SaveMonsterFile(int slotCount);
	bool Load();
	bool LoadPlayerFile(int slotCount);
	bool LoadMonsterFile(int slotCount);
	~GameManager();
};

