#pragma once
#include "MapDraw.h"
#include "Player.h"
#include "Monster.h"
#include <time.h>

enum DUNGEONFLOOR
{
	DUNGEONFLOOR_FRIST = 1,
	DUNGEONFLOOR_SECOND,
	DUNGEONFLOOR_THIRD,
	DUNGEONFLOOR_FOURTH,
	DUNGEONFLOOR_FIVETH,
	DUNGEONFLOOR_SIXTH
};

class Dungeon
{
private:
	int m_X;
	int m_Y;
	MapDraw m_MapDraw;
	Player* m_Player;
	Monster* m_Monster;
	int m_MonsterCount;
	bool* m_bIsPlay;
public:
	Dungeon();
	void DungeonMenu(bool* bIsPlay, Player* player, Monster* monster, int monsterCount);
	void Combat(Monster* monster);
	void DrawCombatInfo(Monster* monster);
	void ShowAttackSelect(char playerSelect, char monsterSelect);
	bool CheckWinner(Monster* monster);
	~Dungeon();
};

