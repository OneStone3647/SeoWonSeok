#pragma once
#include "Mecro.h"
#include "MapDraw.h"

enum SELECT
{
	SELECT_SCISSORS = 49,
	SELECT_ROCK,
	SELECT_PAPER
};

class Character
{
protected:
	static MapDraw m_MapDraw;
	// ĳ���� ����
	// ���� ����: ���ݷ�, �ִ� ü��, �ִ� ����ġ, �޴� ����ġ, ����, ������ �ִ� ���, ���� ����ġ, ���� ü��
protected:
	string m_Name;
	int m_Level;
	int m_Att;
	int m_CurHP;
	int m_MaxHP;
	int m_CurExp;
	int m_MaxExp;
	int m_GetExp;
	int m_HaveGold;
public:
	Character();
	void SetChracterDefaultInfo(string name, int att, int maxHP, int maxExp, int getExp, int level, int haveGold);
	void SetCharacterInfo(string name, int att, int maxHp, int maxExp, int getExp, int level, int haveGold, int curExp, int curHP);
	void ShowCharacterInfo(int x, int y);
	void LevelUp();
	inline void SetDamage(int damage)
	{
		m_CurHP -= damage;
		if (m_CurHP < 0)
		{
			m_CurHP = 0;
		}
	}
	inline void SetCharacterName(string name)
	{
		m_Name = name;
	}
	inline void SetCharacterAtt(int att)
	{
		m_Att = att;
	}
	inline void SetCharacterMaxHP(int maxHP)
	{
		m_MaxHP = maxHP;
	}
	inline void SetCharacterCurHP(int curHP)
	{
		m_CurHP = curHP;
	}
	inline void SetChracterMaxExp(int maxExp)
	{
		m_MaxExp = maxExp;
	}
	inline void SetCharacterCurExp(int curExp)
	{
		m_CurExp = curExp;
	}
	inline void SetCharacterGetExp(int getExp)
	{
		m_GetExp = getExp;
	}
	inline void SetCharacterLevel(int level)
	{
		m_Level = level;
	}
	inline void SetCharacterHaveGold(int haveGold)
	{
		m_HaveGold = haveGold;
	}
	inline void SetCharacterExp(int exp)
	{
		m_CurExp += exp;
		m_GetExp += exp;
	}
	inline void SetHaveGold(int gold)
	{
		m_HaveGold += gold;
	}
	inline string GetCharacterName()
	{
		return m_Name;
	}
	inline int GetCharacterAtt()
	{
		return m_Att;
	}
	inline int GetCharacterMaxHP()
	{
		return m_MaxHP;
	}
	inline int GetCharacterMaxExp()
	{
		return m_MaxExp;
	}
	inline int GetCharacterGetExp()
	{
		return m_GetExp;
	}
	inline int GetCharacterLevel()
	{
		return m_Level;
	}
	inline int GetCharacterHaveGold()
	{
		return m_HaveGold;
	}
	inline int GetCharacterCurExp()
	{
		return m_CurExp;
	}
	inline int GetCharacterCurHP()
	{
		return m_CurHP;
	}
	inline bool IsDead()
	{
		if (m_CurHP <= 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	inline void IncreaseAtt(int att)
	{
		m_Att += att;
	}
	~Character();
};

