#include "Gauntlet.h"



Gauntlet::Gauntlet()
{
}

Gauntlet::Gauntlet(const Weapon & weapon)
	:Weapon(weapon)
{
}

void Gauntlet::Ability(Character * caster, Character * target, int x, int y)
{
	srand((unsigned int)time(NULL));
	int percent = rand() % 100 + 1;		// 1 ~ 100 ������ ����
	int Damage = target->GetCharacterCurHP();
	if (percent <= 100)
	{
		m_MapDraw.DrawMidText("�ΰ� ����!!<Damage: " + to_string(Damage) + ">", x, y);
		target->SetDamage(Damage);
	}
}


Gauntlet::~Gauntlet()
{
}
