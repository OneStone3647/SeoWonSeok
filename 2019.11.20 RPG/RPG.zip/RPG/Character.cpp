#include "Character.h"

MapDraw Character::m_MapDraw;

Character::Character()
{
}

void Character::SetChracterDefaultInfo(string name, int att, int maxHP, int maxExp, int getExp, int level, int haveGold)
{
	m_Name = name;
	m_Att = att;
	m_MaxHP = maxHP;
	m_CurHP = maxHP;
	m_MaxExp = maxExp;
	m_CurExp = 0;
	m_GetExp = getExp;
	m_Level = level;
	m_HaveGold = haveGold;
}

void Character::SetCharacterInfo(string name, int att, int maxHp, int maxExp, int getExp, int level, int haveGold, int curExp, int curHP)
{
	m_Name = name;
	m_Att = att;
	m_MaxHP = maxHp;
	m_CurHP = curHP;
	m_MaxExp = maxExp;
	m_CurExp = curExp;
	m_GetExp = getExp;
	m_Level = level;
	m_HaveGold = haveGold;
}

void Character::ShowCharacterInfo(int x, int y)
{
	m_MapDraw.DrawMidText("======" + m_Name + "(" + to_string(m_Level) + "Lv)======", x, y);
	m_MapDraw.TextDraw("���ݷ� = " + to_string(m_Att), x / 2, y + 1);
	m_MapDraw.TextDraw("������ = " + to_string(m_CurHP) + "/" + to_string(m_MaxHP), x + 2, y + 1);
	m_MapDraw.TextDraw("����ġ = " + to_string(m_CurExp) + "/" + to_string(m_MaxExp), x / 2, y + 2);
	m_MapDraw.TextDraw("GetExp : " + to_string(m_GetExp), x + 2, y + 2);
	m_MapDraw.TextDraw("Gold = " + to_string(m_HaveGold), x / 2, y + 3);
}

void Character::LevelUp()
{
	while (m_CurExp >= m_MaxExp)
	{
		m_CurExp -= m_MaxExp;
		m_Level++;
		if (m_Level % 2 == 0)
		{
			IncreaseAtt(4);
		}
		else
		{
			m_MaxHP += 7;
		}
		m_CurHP = m_MaxHP;
		m_MaxExp += 3;
	}
}


Character::~Character()
{
}
