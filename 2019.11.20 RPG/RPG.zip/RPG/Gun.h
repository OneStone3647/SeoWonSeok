#pragma once
#include "Weapon.h"

class Gun : public Weapon
{
public:
	Gun();
	Gun(const Weapon& weapon);
	virtual void Ability(Character* caster, Character* target, int x, int y);
	~Gun();
};

