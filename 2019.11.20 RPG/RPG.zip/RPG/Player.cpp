#include "Player.h"



Player::Player()
{
	m_HaveWeapon = false;
	m_Weapon = NULL;
}

void Player::SetWeapon(Weapon * weapon)
{
	if (m_Weapon != NULL)
	{
		delete m_Weapon;
	}
	m_Weapon = NULL;
	string weaponType = weapon->GetWeaponType();
	m_HaveWeapon = true;
	if (weaponType == "Bow")
	{
		m_Weapon = new Bow(*weapon);
	}
	else if (weaponType == "Dagger")
	{
		m_Weapon = new Dagger(*weapon);
	}
	else if (weaponType == "Gun")
	{
		m_Weapon = new Gun(*weapon);
	}
	else if (weaponType == "Hammer")
	{
		m_Weapon = new Hammer(*weapon);
	}
	else if (weaponType == "Sword")
	{
		m_Weapon = new Sword(*weapon);
	}
	else if (weaponType == "Wand")
	{
		m_Weapon = new Wand(*weapon);
	}
	else if (weaponType == "Gauntlet")
	{
		m_Weapon = new Gauntlet(*weapon);
	}
}

void Player::ShowPlayerInfo(int x, int y)
{
	if (m_HaveWeapon == true)
	{
		m_MapDraw.DrawMidText("======" + m_Name + "(" + to_string(m_Level) + "Lv)======", x, y);
		m_MapDraw.TextDraw("���ݷ� = " + to_string(m_Att) + " + " + to_string(m_Weapon->GetWeaponAtt()), x / 2, y + 1);
		m_MapDraw.TextDraw("������ = " + to_string(m_CurHP) + "/" + to_string(m_MaxHP), x + 2, y + 1);
		m_MapDraw.TextDraw("����ġ = " + to_string(m_CurExp) + "/" + to_string(m_MaxExp), x / 2, y + 2);
		m_MapDraw.TextDraw("GetExp : " + to_string(m_GetExp), x + 2, y + 2);
		m_MapDraw.TextDraw("Gold = " + to_string(m_HaveGold), x / 2, y + 3);
		m_Weapon->ShowWeaponInfo(x / 2, y + 4);
	}
	else
	{
		ShowCharacterInfo(x, y);
	}
}


Player::~Player()
{
	if (m_Weapon != NULL)
	{
		delete m_Weapon;
	}
}
