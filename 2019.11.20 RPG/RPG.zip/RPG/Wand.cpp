#include "Wand.h"



Wand::Wand()
{
}

Wand::Wand(const Weapon & weapon)
	:Weapon(weapon)
{
}

void Wand::Ability(Character * caster, Character * target, int x, int y)
{
	srand((unsigned int)time(NULL));
	int percent = rand() % 100 + 1;		// 1 ~ 100 ������ ����
	int Damage = target->GetCharacterCurHP();
	if (percent <= 40)
	{
		m_MapDraw.DrawMidText("Ÿ�뽺 �ߵ�!!<Damage: " + to_string(Damage) + ">", x, y);
		target->SetDamage(Damage);
	}
}


Wand::~Wand()
{
}
