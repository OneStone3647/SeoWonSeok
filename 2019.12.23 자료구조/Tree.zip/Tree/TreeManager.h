#pragma once
#include "Tree.h"

enum TREEMANAGER
{
	TREEMAMAGER_INSERT = 1,
	TREEMANAGER_DELETE,
	TREEMANAGER_PREORDER,
	TREEMANAGER_INORDER,
	TREEMANAGER_POSTORDER,
	TREEMANAGER_SEARCH,
	TREEMANAGER_EXIT
};

enum MINNODE
{
	MINNODE_RIGHT = 1,
	MINNODE_LEFT
};

class TreeManager
{
private:
	Tree* m_Root;
public:
	TreeManager();
	void Menu();
	void Insert(Tree* node, int data);
	void PreOrder(Tree* node);
	void InOrder(Tree* node);
	void PostOrder(Tree* node);
	Tree* Search(Tree* node, int data);
	void Release(Tree* node);
	void Delete(Tree* node, int data);
	Tree* ParentNode(Tree* node, int data);
	Tree* MinNode(Tree* node);
	~TreeManager();
};

