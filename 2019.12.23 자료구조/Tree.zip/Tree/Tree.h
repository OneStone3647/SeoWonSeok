#pragma once
#include <iostream>
#include <crtdbg.h>
#include <Windows.h>

using namespace std;

class Tree
{
private:
	int m_Data;
	Tree* m_Left;
	Tree* m_Right;
public:
	Tree();
	inline void SetData(int data)
	{
		m_Data = data;
	}
	inline int GetData()
	{
		return m_Data;
	}
	inline void SetLeft(Tree* node)
	{
		m_Left = node;
	}
	inline Tree* GetLeft()
	{
		return m_Left;
	}
	inline void SetRight(Tree* node)
	{
		m_Right = node;
	}
	inline Tree* GetRight()
	{
		return m_Right;
	}
	~Tree();
};

