#include "Tree.h"



Tree::Tree()
{
	m_Data = 0;
	m_Left = nullptr;
	m_Right = nullptr;
}


Tree::~Tree()
{
}
