#pragma once
#include <iostream>
#include <string>
#include <iomanip>
#include <crtdbg.h>
#include <Windows.h>

using namespace std;


enum MODIFYMENU
{
	MODIFYMENU_NAME = 1,
	MODIFYMENU_AGE,
	MODIFYMENU_ADDRESS,
	MODIFYMENU_SCORE,
	MODIFYMENU_EXIT
};

class Student
{
private:
	string m_Name;
	int m_Age;
	string m_Address;
	int m_LanguageScore;
	int m_EnglishScore;
	int m_MathScore;
	int m_TotalScore;
	float m_AverageScore;
	char m_Rank;
	Student* Next;
public:
	Student();
	inline Student* GetNext()
	{
		return Next;
	}
	inline void SetNext(Student* node)
	{
		Next = node;
	}
	inline string GetName()
	{
		return m_Name;
	}
	void SetName();
	void SetAge();
	void SetAddress();
	void SetScore();
	void ShowDetailInfo();
	void ShowSimpleInfo();
	void InfoModify();
	~Student();
	static Student* Search(Student* next, string name);
	static void Show(Student* next);
	static void Release(Student* next);
	static void Modify(Student* next, string name);
	static void Deleate(Student* next, string name);
	static Student* PrevNode(Student* next, string name);
};

