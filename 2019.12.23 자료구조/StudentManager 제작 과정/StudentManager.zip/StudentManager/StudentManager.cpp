#include "StudentManager.h"



StudentManager::StudentManager()
{
	Head = NULL;
}

void StudentManager::StudentListMenu()
{
	int select;
	string tmpName;
	while (1)
	{
		system("cls");
		cout << " < < < = = = = �޴� = = = = > > >" << endl << endl;
		cout << "1. �л� ���" << endl;
		cout << "2. �л� �˻�" << endl;
		cout << "3. �л� ���" << endl;
		cout << "4. �л� ����" << endl;
		cout << "5. �л� ����" << endl;
		cout << "6. �л� �߰�" << endl;
		cout << "7. ����" << endl;
		cout << "���� : ";
		cin >> select;
		switch (select)
		{
		case STUDENTMANGER_MENU_INSERT:
			if (Head == NULL)
			{
				Head = new Student;
			}
			else
			{
				Insert(Head);
			}
			break;
		case STUDENTMANGER_MENU_SEARCH:
			cout << "�˻��� �̸� �Է� : ";
			cin >> tmpName;
			if (Student::Search(Head, tmpName) == NULL)
			{
				cout << "�ش� ������ �����ϴ�" << endl;
			}
			break;
		case STUDENTMANGER_MENU_SHOW:
			Student::Show(Head);
			break;
		case STUDENTMANGER_MENU_MODIFY:
			cout << "�˻��� �̸� �Է� : ";
			cin >> tmpName;
			Student::Modify(Head, tmpName);
			break;
		case STUDENTMANGER_MENU_DELETE:
			if (Head != NULL)
			{
				cout << "�˻��� �̸� �Է� : ";
				cin >> tmpName;
				if (Head->GetName() == tmpName)
				{
					Student*tmpdelete = Head;
					Head = Head->GetNext();
				}
				else
				{
					Student::Deleate(Head, tmpName);
				}
			}
			break;
		case STUDENTMANGER_MENU_ADD:
			break;
		case STUDENTMANGER_MENU_EXIT:
			if (Head != NULL)
			{
				Student::Release(Head);
				delete Head;
			}
			break;
		}
		system("pause");
	}
}

void StudentManager::Insert(Student * node)
{
	if (node->GetNext() != NULL)
	{
		Insert(node->GetNext());
	}
	else
	{
		node->SetNext(new Student);
	}
}


StudentManager::~StudentManager()
{
}
