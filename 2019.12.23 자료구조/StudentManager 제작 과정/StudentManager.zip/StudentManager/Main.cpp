#include "StudentManager.h"

void main()
{
	StudentManager SManager;
	SManager.StudentListMenu();
}