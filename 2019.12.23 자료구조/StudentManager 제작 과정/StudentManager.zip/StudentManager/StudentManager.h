#pragma once
#include "Student.h"

enum STUDENTMANGER_MENU
{
	STUDENTMANGER_MENU_INSERT = 1,
	STUDENTMANGER_MENU_SEARCH,
	STUDENTMANGER_MENU_SHOW,
	STUDENTMANGER_MENU_MODIFY,
	STUDENTMANGER_MENU_DELETE,
	STUDENTMANGER_MENU_ADD,
	STUDENTMANGER_MENU_EXIT
};

class StudentManager
{
private:
	Student* Head;
public:
	StudentManager();
	void StudentListMenu();
	void Insert(Student* node);
	~StudentManager();
};

