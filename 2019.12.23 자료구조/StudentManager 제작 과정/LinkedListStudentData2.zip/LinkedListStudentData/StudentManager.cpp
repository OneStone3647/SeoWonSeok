#include "StudentManager.h"



StudentManager::StudentManager()
{
	pHead = NULL;
}


void StudentManager::StudentListMenu()
{
	int iSelect;
	string tmpName;
	cout << "==== �޴� ====" << endl << endl;
	cout << "1.�л� ���" << endl;
	cout << "2.�л� �˻�" << endl;
	cout << "3.�л� ���" << endl;
	cout << "4.�л� ����" << endl;
	cout << "5.�л� ����" << endl;
	cout << "6.�л� �߰�" << endl;
	cout << "7.����" << endl;
	cout << "���� : ";
	cin >> iSelect;
	switch (iSelect)
	{
	case STUDENTMANAGER_MENU_INSERT:
		if (pHead == NULL)
			pHead = new Student;
		else
			Insert(pHead);
		break;
	case STUDENTMANAGER_MENU_SEARCH:
		cout << "�˻��� �̸� �Է� : ";
		cin >> tmpName;
		if (Student::Search(pHead, tmpName) == false)
			cout << "�ش� ������ �����ϴ�." << endl;
		break;
	case STUDENTMANAGER_MENU_SHOW:
		Student::Show(pHead);
		break;
	case STUDENTMANAGER_MENU_MODIFY:
		break;
	case STUDENTMANAGER_MENU_DELETE:
		break;
	case STUDENTMANAGER_MENU_ADD:
		break;
	case STUDENTMANAGER_MENU_EXIT:
		break;
	}
}


void StudentManager::Insert(Student* pNode)
{
	if (pNode->GetNext() != NULL)
		Insert(pNode->GetNext());
	else
		pNode->SetNext(new Student);
}


StudentManager::~StudentManager()
{
}
