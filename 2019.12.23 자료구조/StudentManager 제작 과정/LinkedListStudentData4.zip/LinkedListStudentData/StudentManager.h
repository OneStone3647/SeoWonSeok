#pragma once
#include"Student.h"

enum STUDENTMANAGER_MENU
{
	STUDENTMANAGER_MENU_INSERT = 1,
	STUDENTMANAGER_MENU_SEARCH,
	STUDENTMANAGER_MENU_SHOW,
	STUDENTMANAGER_MENU_MODIFY,
	STUDENTMANAGER_MENU_DELETE,
	STUDENTMANAGER_MENU_ADD,
	STUDENTMANAGER_MENU_EXIT
};

class StudentManager
{
private:
	Student* pHead;
public:
	void StudentListMenu();
	void Insert(Student* pNode);
	StudentManager();
	~StudentManager();
};

