#pragma once
#include<iostream>
#include<string>
#include<Windows.h>
using namespace std;

enum MODIFYMENU
{	
	MODIFYMENU_NAME = 1,
	MODIFYMENU_AGE,
	MODIFYMENU_ADDRASS,
	MODIFYMENU_SCORE,
	MODIFYMENU_EXIT
};

class Student
{
private:
	string m_strName;
	int m_iAge;
	string m_strAddress;
	int m_iKor;
	int m_iMath;
	int m_iEng;
	int m_iSum;
	float m_fAvg;
	char m_chGrade;
	Student* pNext;
public:
	inline Student* GetNext() { return pNext; }
	inline void SetNext(Student* pNode) { pNext = pNode; }
	inline string GetName() { return m_strName; }
	void SetName();
	void SetAge();
	void SetAddress();
	void SetScore();
	void ShowDetailInfomation();
	void ShowSimpleInfomation();
	void Modify();
	Student();
	~Student();
	static Student* Search(Student* pNext, string Name);
	static void Show(Student* pNext);
	static void Release(Student* pNext);
	static void Modify(Student* pNext,string Name);
	static void Delete(Student* pNext, string Name);
	static Student* PrevNode(Student* pNext, string Name);
};

