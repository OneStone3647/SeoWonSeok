#include"StudentManager.h"

void main()
{
	StudentManager StudentManager;
	StudentManager.StudentListMenu();
}