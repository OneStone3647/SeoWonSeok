#include "Snake.h"



Snake::Snake()
{
	m_SnakeHeadShape = "��";
	m_SnakeTailShape = "��";
	m_Head = NULL;
}

// ó�� ����
void Snake::SetSnake(int width, int height)
{
	m_Head = new Point;
	m_Head->m_Number = 0;
	m_Head->m_X = width / 2;
	if (m_Head->m_X & 2 == 1)
	{
		m_Head->m_X++;
	}
	m_Head->m_Y = height / 2;
	m_Head->Next = NULL;
	m_TailCount = 0;
	m_MoveSpeed = DEFAULT_MOVESPEED;
}

void Snake::Move(char key, int x, int y)
{
	if (m_TailCount > 0)
	{
		UpdateTail(m_Head);
	}
	switch (key)
	{
	case KEY_UP:
		if (m_Head->m_Y > 0)
		{
			m_Head->m_LastY = m_Head->m_Y;
			m_Head->m_Y--;
		}
		break;
	case KEY_LEFT:
		if (m_Head->m_X > 0)
		{
			m_Head->m_LastX = m_Head->m_X;
			m_Head->m_X--;
		}
		break;
	case KEY_DOWN:
		if (m_Head->m_Y + 1 < y)
		{
			m_Head->m_LastY = m_Head->m_Y;
			m_Head->m_Y++;
		}
		break;
	case KEY_RIGHT:
		if (m_Head->m_X + 1 < x)
		{
			m_Head->m_LastX = m_Head->m_X;
			m_Head->m_X++;
		}
		break;
	}
}

void Snake::Release(Point * Node)
{
	if (Node == NULL)
	{
		return;
	}
	Release(Node->Next);
	delete Node;
	if (m_TailCount != 0)
	{
		m_TailCount--;
	}
}

void Snake::AddTail(Point * Node)
{
	// ���� ���ڿ�������
	Point* tmp;
	Point* add;
	m_TailCount++;
	tmp = m_Head;
	if (m_TailCount == 1)		// �� ó�� ����
	{
		add = new Point;
		add->m_X = tmp->m_X;
		add->m_Y = tmp->m_Y;
		add->Next = NULL;
		add->m_Number = m_TailCount;
		tmp->Next = add;
	}
	else
	{
		while (tmp->Next != NULL)
		{
			tmp = tmp->Next;
		}
		add = new Point;
		add->m_X = tmp->m_X;
		add->m_Y = tmp->m_Y;
		add->Next = NULL;
		add->m_Number = m_TailCount;
		tmp->Next = add;
	}
	//IncreaseMoveSpeed();
}

void Snake::DrawSnake(Point * Node)
{
	Point* tmp = Node;
	if (tmp->m_Number == 0)
	{
		m_DrawManager.DrawPoint(m_SnakeHeadShape, Node->m_X, Node->m_Y);
	}
	if (tmp->Next == NULL)
	{
		return;
	}
	DrawSnake(Node->Next);
	m_DrawManager.DrawPoint(m_SnakeTailShape, Node->Next->m_X, Node->Next->m_Y);
}

// ���ڸ��� ��ǥ�� ���� ��ǥ�� �ű�
void Snake::UpdateTail(Point * Node)
{
	Point* tmp = Node;
	if (tmp->Next == NULL)
	{
		return;
	}
	UpdateTail(Node->Next);
	Node->Next->m_X = tmp->m_X;
	Node->Next->m_Y = tmp->m_Y;
}

bool Snake::CheckWallHit()
{
	if (m_Head->m_X == 0 || m_Head->m_X == WIDTH - 1 || m_Head->m_Y == 0 || m_Head->m_Y == HEIGHT - 1)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Snake::CheckTailHit()
{
	bool bCheck = false;
	Point* tmp = m_Head;
	while (tmp->Next != NULL)
	{
		tmp = tmp->Next;
		// ù��°, �ι�° ���� ����
		if (m_TailCount > 2 && m_Head->m_X == tmp->m_X && m_Head->m_Y == tmp->m_Y)
		{
			bCheck = true;
		}
	}
	// ������ ����
	if (m_TailCount > 2 && tmp->Next == NULL)
	{
		if (m_Head->m_X == tmp->m_X && m_Head->m_Y == tmp->m_Y)
		{
			bCheck = true;
		}
	}
	return bCheck;
}

bool Snake::CheckBlockHit()
{
	if (m_ObjectManager.CheckBlock(m_Head->m_X, m_Head->m_Y))
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Snake::CheckIsDead()
{
	// ���� ����� ��
 	if (CheckWallHit())
	{
		Release(m_Head);
		return true;
	}
	if (CheckTailHit())
	{
		Release(m_Head);
		return true;
	}
	//if (CheckBlockHit())
	//{
	//	IsDead();
	//	return true;
	//}
	return false;
}

Point * Snake::GetSnakeLastTail()
{
	Point* tmp = m_Head;
	while (tmp->Next != NULL)
	{
		tmp = tmp->Next;
		if (tmp->Next == NULL)
		{
			return tmp;
		}
	}
	return nullptr;
}


Snake::~Snake()
{
}
