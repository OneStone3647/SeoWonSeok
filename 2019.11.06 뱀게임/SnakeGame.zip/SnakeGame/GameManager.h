#pragma once
#include "DrawManager.h"
#include "ObjectManager.h"
#include "Snake.h"

enum MAINMENU
{
	MAINMENU_PLAY = 1,
	MAINMENU_END
};

class GameManager
{
private:
	DrawManager m_DrawManager;
	ObjectManager m_ObjectManager;
	Snake* m_Snake;
	int m_Width;
	int m_Height;
	bool m_bPlayState;
	bool m_bFirstInput;
	int m_Score;
	int m_FoodCount;
	int* m_FoodCountptr;
public:
	GameManager();
	void MainMenu();
	void Init();
	void Play();
	void GameOver();
	void Input();
	void AddScore();
	~GameManager();
};

