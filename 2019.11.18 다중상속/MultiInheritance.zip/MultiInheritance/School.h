#pragma once
#include "Mecro.h"

struct SchoolInfo
{
	int m_Grade;
	int m_Class;
	int m_Number;
};

class School
{
protected:
	SchoolInfo m_SchoolInfo;
protected:
	void SetSchoolnfo();
	void DrawSchoolInfo();
public:
	School();
	~School();
};

