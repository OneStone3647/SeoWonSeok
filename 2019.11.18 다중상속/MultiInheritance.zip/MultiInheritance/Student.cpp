#include "Student.h"



Student::Student()
{
}

void Student::SetStudentInfo()
{
	SetSchoolnfo();
	SetPersonInfo();
}

void Student::DrawStudentInfo()
{
	system("cls");
	DrawSchoolInfo();
	DrawPersonInfo();
}


Student::~Student()
{
}
