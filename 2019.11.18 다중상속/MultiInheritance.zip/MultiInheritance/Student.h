#pragma once
#include "Person.h"
#include "School.h"

class Student : public Person, public School
{
public:
	Student();
	void SetStudentInfo();
	void DrawStudentInfo();
	~Student();
};

