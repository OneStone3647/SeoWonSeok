#pragma once
#include "Mecro.h"

struct PersonInfo
{
	string m_Gender;
	int m_Age;
	string m_Name;
};

class Person
{
protected:
	PersonInfo m_PersonInfo;
protected:
	void SetPersonInfo();
	void DrawPersonInfo();
public:
	Person();
	~Person();
};

