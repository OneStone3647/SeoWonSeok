#include "School.h"



void School::SetSchoolnfo()
{
	cout << "�г� �Է� : ";
	cin >> m_SchoolInfo.m_Grade;
	cout << "�� �Է� : ";
	cin >> m_SchoolInfo.m_Class;
	cout << "�л� ��ȣ �Է� : ";
	cin >> m_SchoolInfo.m_Number;
}

void School::DrawSchoolInfo()
{
	cout << m_SchoolInfo.m_Grade << " �г� " << m_SchoolInfo.m_Class << " �� " << m_SchoolInfo.m_Number << " �� �л�" << endl;
}

School::School()
{
}


School::~School()
{
}
