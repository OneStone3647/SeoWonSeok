#include "Student.h"

void main()
{
	Student student;
	student.SetStudentInfo();
	student.DrawStudentInfo();
}