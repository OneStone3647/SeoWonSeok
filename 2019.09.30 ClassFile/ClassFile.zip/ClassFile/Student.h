#pragma once
#include <iostream>
#include <string>
using namespace std;

enum GENDER
{
	GENDER_MAN,
	GENDER_WOMAN
};

enum CLASS
{
	CLASS_START = 1,
	CLASS_1 = 1,
	CLASS_2,
	CLASS_3,
	CLASS_END
};

class Student
{
private:
	string m_name;
	int m_age;
	GENDER m_gender;
	CLASS m_class;
	int m_number;

public:
	void SetStudent(int number);
	void ShowStudent();
	inline string GetName()
	{
		return m_name;
	}
	inline CLASS GetClass()
	{
		return m_class;
	}
	Student();
	~Student();
};

