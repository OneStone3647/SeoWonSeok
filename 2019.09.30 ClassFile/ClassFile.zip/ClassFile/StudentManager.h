#pragma once
#include "Student.h"

#define STUDENT_MAX 10

class StudentManager
{
private:
	int m_studentCount = 0;
	Student* m_studentList[STUDENT_MAX];
public:
	void AddStudent();
	void ShowStudentList();
	void ShowClass(int Class);
	inline int GetStudentCount()
	{
		return m_studentCount;
	}
	bool FindStudentName(string Name);
	void DeleteLastStudent();
	void DeleteAllStudent();
	StudentManager();
	~StudentManager();
};

