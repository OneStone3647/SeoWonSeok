#include "Interface.h"



Interface::Interface()
{
	m_MapWidth = 20;
	m_MapHeight = 20;
}

void Interface::MainMenu(int width, int height)
{
	m_MapWidth = width;
	m_MapHeight = height;
	int m_Y = m_MapHeight / 2;
	system("cls");
	m_DrawManager.DrawMap(m_MapWidth, m_MapHeight);
	m_DrawManager.DrawMidText("�� �� �� ��", m_MapWidth, m_Y - 4);
	m_DrawManager.DrawMidText("1.���� ����", m_MapWidth, m_Y - 2);
	m_DrawManager.DrawMidText("2.�ɼ� ����", m_MapWidth, m_Y);
	m_DrawManager.DrawMidText("3.���� ����", m_MapWidth, m_Y + 2);
	m_DrawManager.DrawMidText("��������������������", m_MapWidth, m_Y + 4);
	m_DrawManager.DrawMidText("��                ��", m_MapWidth, m_Y + 5);
	m_DrawManager.DrawMidText("��������������������", m_MapWidth, m_Y + 6);
	m_DrawManager.gotoxy(m_MapWidth, m_Y + 5);
}

void Interface::OptionMenu(int width, int height)
{
	m_MapWidth = width;
	m_MapHeight = height;
	m_Y = m_MapHeight / 2;
	system("cls");
	m_DrawManager.DrawBox(m_MapWidth, m_MapHeight);
	m_DrawManager.DrawMidText("= Option =", m_MapWidth, m_Y - 6);
	m_DrawManager.DrawMidText("1.Map Size Set", m_MapWidth, m_Y - 4);
	m_DrawManager.DrawMidText("2.Cursor Custom", m_MapWidth, m_Y - 2);
	m_DrawManager.DrawMidText("3.Stone Custom", m_MapWidth, m_Y);
	m_DrawManager.DrawMidText("4.Undo Count Set", m_MapWidth, m_Y + 2);
	m_DrawManager.DrawMidText("5.Return", m_MapWidth, m_Y + 4);
	m_DrawManager.DrawMidText("�Է� : ", m_MapWidth, m_Y + 6);
	m_DrawManager.gotoxy(m_MapWidth + 4, m_Y + 6);
}

void Interface::MapSizeSet(int * width, int * height)
{
	int MapWidth, MapHeight;
	while (1)
	{
		system("cls");
		m_DrawManager.DrawBox(m_MapWidth, m_MapHeight);
		m_DrawManager.DrawMidText("Width : ", m_MapWidth, m_Y);
		cin >> MapWidth;
		m_DrawManager.DrawMidText("Height : ", m_MapWidth, m_Y + 2);
		cin >> MapHeight;
		if ((MapWidth >= 20 && MapWidth <= 90) && (MapHeight >= 20 && MapHeight <= 45))
		{
			*width = MapWidth;
			*height = MapHeight;
			return;
		}
		else
		{
			m_DrawManager.DrawMidText("���� �Ұ���", m_MapWidth, m_Y);
			m_DrawManager.DrawMidText("(���� : 20 ~ 90, ���� : 20 ~ 45)", m_MapWidth, m_Y + 2);
			system("pause");
		}
	}
}

void Interface::CursorCustom()
{
	system("cls");
	m_DrawManager.DrawBox(m_MapWidth, m_MapHeight);
	m_DrawManager.DrawMidText("= Set Cursor =", m_MapWidth, m_Y - 6);
	m_DrawManager.DrawMidText("1.��, ��", m_MapWidth, m_Y - 4);
	m_DrawManager.DrawMidText("2.��, ��", m_MapWidth, m_Y - 2);
	m_DrawManager.DrawMidText("3.��, ��", m_MapWidth, m_Y);
	m_DrawManager.DrawMidText("4.��, ��", m_MapWidth, m_Y + 2);
	m_DrawManager.DrawMidText("5.Return", m_MapWidth, m_Y + 4);
	m_DrawManager.DrawMidText("�Է� : ", m_MapWidth, m_Y + 6);
}

void Interface::StoneCustom()
{
	system("cls");
	m_DrawManager.DrawBox(m_MapWidth, m_MapHeight);
	m_DrawManager.DrawMidText("= Set Stone =", m_MapWidth, m_Y - 6);
	m_DrawManager.DrawMidText("1.��, ��", m_MapWidth, m_Y - 4);
	m_DrawManager.DrawMidText("2.��, ��", m_MapWidth, m_Y - 2);
	m_DrawManager.DrawMidText("3.��, ��", m_MapWidth, m_Y);
	m_DrawManager.DrawMidText("4.��, ��", m_MapWidth, m_Y + 2);
	m_DrawManager.DrawMidText("5.Return", m_MapWidth, m_Y + 4);
	m_DrawManager.DrawMidText("�Է� : ", m_MapWidth, m_Y + 6);
}

void Interface::UndoCountSet()
{
	system("cls");
	m_DrawManager.DrawBox(m_MapWidth, m_MapHeight);
	m_DrawManager.DrawMidText("= Set Undo =", m_MapWidth, m_Y - 4);
	m_DrawManager.DrawMidText("1.Set Undo Count", m_MapWidth, m_Y - 2);
	m_DrawManager.DrawMidText("2.Undo Off", m_MapWidth, m_Y);
	m_DrawManager.DrawMidText("3.Return", m_MapWidth, m_Y + 2);
	m_DrawManager.DrawMidText("�Է� : ", m_MapWidth, m_Y + 4);	
}

void Interface::SetUndoDis()
{
	m_DrawManager.DrawBox(m_MapWidth, m_MapHeight);
	m_DrawManager.DrawMidText("������ Ƚ�� �Է�(�ִ� 10ȸ) : ", m_MapWidth, m_Y);
}

void Interface::SetUndoFail()
{
	m_DrawManager.DrawMidText("������ ���� �ʽ��ϴ�. (0 ~ 10)", m_MapWidth, m_Y + 2);
	system("pause");
}

void Interface::UndoOffDis()
{
	m_DrawManager.DrawBox(m_MapWidth, m_MapHeight);
	m_DrawManager.DrawMidText("������ Off", m_MapWidth, m_Y);
	system("pause");
}

void Interface::DrawInfo(Player * player, int turn)
{
	m_DrawManager.DrawMidText("====����Ű====", m_MapWidth, m_MapHeight);
	m_DrawManager.DrawMidText("�̵� : A,S,W,D ������ : ENTER", m_MapWidth, m_MapHeight + 1);
	m_DrawManager.DrawMidText("������ : N �ɼ� : P ���� : ESC", m_MapWidth, m_MapHeight + 2);
	string tmp;
	tmp = "Player Name : ";
	tmp += player->GetTeamName();
	tmp += " ������ : ";
	string str = to_string((*player).GetUndo());
	tmp += str;
	m_DrawManager.DrawMidText(tmp, m_MapWidth, m_MapHeight + 3);
	tmp = "Turn : ";
	str = to_string(turn);
	tmp += str;
	m_DrawManager.DrawMidText(tmp, m_MapWidth, m_MapHeight + 4);
}

void Interface::AccessDenied()
{
	system("cls");
	m_DrawManager.DrawMidText("���� �Ұ���", m_MapWidth, m_Y - 2);
	m_DrawManager.DrawMidText("(Game Play��)", m_MapWidth, m_Y);
	system("pause");
}

void Interface::VictoryDis(int teamNum)
{
	if (teamNum == PLAYER1)
	{
		m_DrawManager.DrawMidText("1�� �¸�!!", m_MapWidth, m_Y);
	}
	if (teamNum == PLAYER2)
	{
		m_DrawManager.DrawMidText("2�� �¸�!!", m_MapWidth, m_Y);
	}
	system("pause");
}


Interface::~Interface()
{
}
