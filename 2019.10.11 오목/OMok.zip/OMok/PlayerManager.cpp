#include "PlayerManager.h"



PlayerManager::PlayerManager()
{
	m_MapWidth = 20;
	m_MapHeight = 20;

	m_Player1 = new Player;
	m_Player1->SetStone(PLAYER1, 1);
	m_Player1->SetCursor(PLAYER1, 1);

	m_Player2 = new Player;
	m_Player2->SetStone(PLAYER2, 1);
	m_Player2->SetCursor(PLAYER2, 1);
}

Player * PlayerManager::GetPlayer(int PlayerNum)
{
	if (PlayerNum == PLAYER1)
	{
		return m_Player1;
	}
	if (PlayerNum == PLAYER2)
	{
		return m_Player2;
	}
}

void PlayerManager::Init(int Width, int Height)
{
	string tmp;
	m_MapWidth = Width;
	m_MapHeight = Height;
	int m_Y = m_MapHeight / 2;
	system("cls");
	m_DrawManager.DrawBox(m_MapWidth, m_MapHeight);

	m_DrawManager.DrawMidText("P1 �̸�", m_MapWidth, m_Y - 3);
	m_DrawManager.DrawMidText("�Է� : ", m_MapWidth, m_Y - 2);
	cin >> tmp;
	m_Player1->SetPlayer(tmp, m_MapWidth, m_MapHeight);

	m_DrawManager.DrawMidText("P2 �̸�", m_MapWidth, m_Y);
	m_DrawManager.DrawMidText("�Է� : ", m_MapWidth, m_Y + 1);
	cin >> tmp;
	m_Player2->SetPlayer(tmp, m_MapWidth, m_MapHeight);
}

void PlayerManager::SetPlayerCursor(int CursorShapeNum)
{
	m_Player1->SetCursor(PLAYER1, CursorShapeNum);
	m_Player2->SetCursor(PLAYER2, CursorShapeNum);
}

void PlayerManager::SetPlayerStone(int StoneShapeNum)
{
	m_Player1->SetStone(PLAYER1, StoneShapeNum);
	m_Player2->SetStone(PLAYER2, StoneShapeNum);
}

void PlayerManager::SetPlayerUndo(int SetCount)
{
	m_Player1->SetUndo(SetCount);
	m_Player2->SetUndo(SetCount);
}

void PlayerManager::DrawPlayer(int teamNum)
{
	Player* tmpPlayer;
	tmpPlayer = GetPlayer(teamNum);
	m_DrawManager.DrawPoint(tmpPlayer->GetCursorShape(), tmpPlayer->GetX(), tmpPlayer->GetY());
}

void PlayerManager::DrawPlayer(Player * Player)
{
	m_DrawManager.DrawPoint(Player->GetCursorShape(), Player->GetX(), Player->GetY());
}

void PlayerManager::DrawPlayer(Player * Player, int X, int Y)
{
	m_DrawManager.DrawPoint(Player->GetStoneShape(), X, Y);
}

void PlayerManager::ErasePlayer(Player * Player)
{
	m_DrawManager.ErasePoint(Player->GetX(), Player->GetY());
	if (!CheckStone(Player->GetX(), Player->GetY()))
	{
		m_DrawManager.ReDrawPoint(Player->GetX(), Player->GetY(), m_MapWidth, m_MapHeight);
	}
}

bool PlayerManager::CheckStone(int x, int y)
{
	if (m_Player1->FineStone(x, y))
	{
		m_DrawManager.DrawPoint(m_Player1->GetStoneShape(), x, y);
		return true;
	}
	if (m_Player2->FineStone(x, y))
	{
		m_DrawManager.DrawPoint(m_Player2->GetStoneShape(), x, y);
		return true;
	}
	return false;
}

void PlayerManager::DrawAllStone()
{
	int P1StoneIndex = m_Player1->GetStoneIdnex();
	for (int i = 0; i < P1StoneIndex; i++)
	{
		m_DrawManager.DrawPoint(m_Player1->GetStoneShape(), m_Player1->GetStoneX(i), m_Player1->GetStoneY(i));
	}
	int P2StoneIndex = m_Player2->GetStoneIdnex();
	for (int i = 0; i < P2StoneIndex; i++)
	{
		m_DrawManager.DrawPoint(m_Player2->GetStoneShape(), m_Player2->GetStoneX(i), m_Player2->GetStoneY(i));
	}
}


void PlayerManager::EraseLastStone(Player * Player)
{
	int StoneIndex;
	int x, y;
	if (Player->GetTeamNum() == m_Player1->GetTeamNum())
	{
		StoneIndex = Player->GetStoneIdnex();
		m_DrawManager.ErasePoint(Player->GetStoneX(StoneIndex - 1), Player->GetStoneY(StoneIndex - 1));
		m_DrawManager.ReDrawPoint(Player->GetStoneX(StoneIndex - 1), Player->GetStoneY(StoneIndex - 1), m_MapWidth, m_MapHeight);
	}
	if (Player->GetTeamNum() == m_Player2->GetTeamNum())
	{
		StoneIndex = Player->GetStoneIdnex();
		m_DrawManager.ErasePoint(Player->GetStoneX(StoneIndex - 1), Player->GetStoneY(StoneIndex - 1));
		m_DrawManager.ReDrawPoint(Player->GetStoneX(StoneIndex - 1), Player->GetStoneY(StoneIndex - 1), m_MapWidth, m_MapHeight);
	}
}

bool PlayerManager::IsUndo(Player * player)
{
	ErasePlayer(player);
	EraseLastStone(player);
	player->UndoStone();
	return false;
}

bool PlayerManager::Input(Player * player, int * turn, bool * bIsPlaying, bool * bUndo, bool * bOption)
{
	char key;
	bool bCheck = true;
	while (bCheck)
	{
		DrawPlayer(player);
		key = getch();
		ErasePlayer(player);
		switch (key)
		{
		case DIRECTION_UP:
			if (player->GetY() > 0)
			{
				player->SetLastY(player->GetY());
				player->PlusY(-1);
			}
			return false;
		case DIRECTION_LEFT:
			if (player->GetX() * 2 > 0)
			{
				player->SetLastX(player->GetX());
				player->PlusX(-1);
			}
			return false;
		case DIRECTION_DOWN:
			if (player->GetY() < m_MapHeight - 1)
			{
				player->SetLastY(player->GetY());
				player->PlusY(1);
			}
			return false;
		case DIRECTION_RIGHT:
			if (player->GetX() * 2 < m_MapWidth * 2 - 3)
			{
				player->SetLastX(player->GetX());
				player->PlusX(1);
			}
			return false;
		case PUT:
			if (!CheckStone(player->GetX(), player->GetY()))
			{
				player->PutStone();
				DrawPlayer(player);
				if (player->GetStoneIdnex() > 4)
				{
					if (player->CheckVictoryHorizontal() || player->CheckVictoryVertical() || player->CheckVictoryRightUP() || player->CheckVictoryLeftUP())
					{
						return true;
					}
				}
				bCheck = false;
			}
			break;
		case ESC:
			*bIsPlaying = false;
			return false;
		case UNDO:
			Player* tmpPlayer;
			if (player->GetTeamNum() == PLAYER1)
			{
				tmpPlayer = GetPlayer(PLAYER2);
			}
			if (player->GetTeamNum() == PLAYER2)
			{
				tmpPlayer = GetPlayer(PLAYER1);
			}
			if (player->GetUndo() > 0 && tmpPlayer->GetStoneIdnex() != 0)
			{
				ErasePlayer(player);
				player->DecreaseUndo();
				*bUndo = true;
				bCheck = false;
			}
			break;
		case OPTION:
			*bOption = true;
			return false;
		}
		if (!(*bUndo))
		{
			DrawPlayer(player);
		}
	}
	if (*bUndo)
	{
		*turn -= 1;
	}
	else
	{
		*turn += 1;
	}
	return false;
}

PlayerManager::~PlayerManager()
{
	delete m_Player1;
	delete m_Player2;
}
