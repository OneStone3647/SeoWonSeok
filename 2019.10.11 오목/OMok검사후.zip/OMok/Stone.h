#pragma once
class Stone
{
private:
	int m_X, m_Y;
public:
	inline int GetX()
	{
		return m_X;
	}
	inline int GetY()
	{
		return m_Y;
	}
	inline void SetX(int x)
	{
		m_X = x;
	}
	inline void SetY(int y)
	{
		m_Y = y;
	}
};

