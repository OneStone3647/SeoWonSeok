#pragma once
#include "Stone.h"
#include "Mecro.h"

#define PLAYER1 1
#define PLAYER2 2
#define PUT 13
#define ESC 27
#define UNDO 110
#define OPTION 112

enum DIRCTION
{
	DIRECTION_UP = 'w',
	DIRECTION_LEFT = 'a',
	DIRECTION_DOWN = 's',
	DIRECTION_RIGHT = 'd'
};

class Player
{
private:
	int m_TeamNum;
	string m_TeamName;
	string m_StoneShape, m_CursorShape;
	int m_X, m_Y;
	int m_LastX, m_LastY;
	int m_MapWidth, m_MapHeight;
	int m_MaxStoneNum;
	int m_StoneIndex;
	int m_Undo;
	Stone* m_Stone;
public:
	Player();
	void SetPlayer(string teamName, int width, int height);
	void SetStone(int teamNum, int stoneShapeNum);
	void SetCursor(int teamNum, int cursorShapeNum);
	inline void SetUndo(int setCount)
	{
		m_Undo = setCount;
	}
	void PutStone();
	void UndoStone();
	bool FineStone(int x, int y);
	bool CheckVictoryHorizontal();
	bool CheckVictoryVertical();
	bool CheckVictoryRightUP();
	bool CheckVictoryLeftUP();
	inline int GetStoneX(int index)
	{
		return m_Stone[index].GetX();
	}
	inline int GetStoneY(int index)
	{
		return m_Stone[index].GetY();
	}
	inline string GetStoneShape()
	{
		return m_StoneShape;
	}
	inline string GetCursorShape()
	{
		return m_CursorShape;
	}
	inline int GetX()
	{
		return m_X;
	}
	inline int GetY()
	{
		return m_Y;
	}
	inline void PlusX(int x)
	{
		m_X += x;
	}
	inline void PlusY(int y)
	{
		m_Y += y;
	}
	inline int GetLastX()
	{
		return m_LastX;
	}
	inline int GetLastY()
	{
		return m_LastY;
	}
	inline void SetLastX(int x)
	{
		m_LastX = x;
	}
	inline void SetLastY(int y)
	{
		m_LastY = y;
	}
	inline string GetTeamName()
	{
		return m_TeamName;
	}
	inline int GetUndo()
	{
		return m_Undo;
	}
	inline int GetStoneIdnex()
	{
		return m_StoneIndex;
	}
	inline int DecreaseUndo()
	{
		return m_Undo--;
	}
	inline int GetTeamNum()
	{
		return m_TeamNum;
	}
	~Player();
};

