#pragma once
#include "Interface.h"

struct Point
{
	int m_X;
	int m_Y;
};

enum ITEMINDEX
{
	ITEMINDEX_NONE,
	ITEMINDEX_SPDUP,
	ITEMINDEX_SPDDOWN,
	ITEMINDEX_PAUSE,
	ITEMINDEX_CLEAR,
	ITEMINDEX_HIDE
};

class Word
{
private:
	Interface m_Interface;
	Point m_Point;
	string m_Word;
	bool m_bLive;		// �ܾ ȭ�鿡 ��µ� �� true
	bool m_bUnder;		// �ܾ �ٴڿ� ���� �� true
	bool m_bHide;
	ITEMINDEX m_ItemIndex;
public:
	Word();
	void Init();
	void DrawWord();
	void EraseWord();
	void SetItem();
	inline ITEMINDEX GetItemIndex()
	{
		return m_ItemIndex;
	}
	inline int GetPointX()
	{
		return m_Point.m_X;
	}
	inline int GetPointY()
	{
		return m_Point.m_Y;
	}
	inline string GetWord()
	{
		return m_Word;
	}
	inline bool GetLive()
	{
		return m_bLive;
	}
	inline bool GetUnder()
	{
		return m_bUnder;
	}
	inline void SetWord(string word)
	{
		m_Word = word;
	}
	inline void SetWordLive(bool bLive)
	{
		m_bLive = bLive;
	}
	inline void SetWordUnder(bool bUnder)
	{
		m_bUnder = bUnder;
	}
	inline void SetPointX(int x)
	{
		m_Point.m_X = x;
	}
	inline void SetPointY(int y)
	{
		m_Point.m_Y = y;
	}
	inline void SetHideWord(bool flag)
	{
		m_bHide = flag;
	}
	~Word();
};

