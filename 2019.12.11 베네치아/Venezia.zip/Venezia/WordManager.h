#pragma once
#include "Word.h"
#include "Player.h"

#define ITEM_ACTIVE_TIME 1500

class WordManager
{
private:
	Interface m_Interface;
	Player* m_Player;
	Word* m_Word;
	int m_WordCount;
	int m_SetTimer;
	int m_DropTimer;
	int m_HideTimer;
	int m_PauseTimer;
	int m_SetSpeed;
	int m_DropSpeed;
	bool m_bPauseFlag;
	bool m_bHideFlag;
public:
	WordManager();
	void CheckWordFile();
	void Init(Player* player);
	void Update();
	void SetWord();
	void DropWord();
	void UnderWord();
	bool SearchAnswer();
	void ActiveItem(ITEMINDEX index);
	void IncreaseSpeed();
	void DecreaseSpeed();
	void PauseWord();
	void ClearWord();
	void HideWord(bool flag);
	inline int GetSetSpeed()
	{
		return m_SetSpeed;
	}
	inline int GetDropSpeed()
	{
		return m_DropSpeed;
	}
	~WordManager();
};

