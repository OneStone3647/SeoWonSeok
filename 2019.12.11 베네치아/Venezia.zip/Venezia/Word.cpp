#include "Word.h"



Word::Word()
{
	m_Point.m_Y = 1;
	m_bLive = false;
	m_bUnder = false;
	m_bHide = false;
	m_ItemIndex = ITEMINDEX_NONE;
}

void Word::Init()
{
	m_bLive = false;
	m_bUnder = false;
	m_bHide = false;
	m_Point.m_Y = 1;
}

void Word::DrawWord()
{
	if (m_ItemIndex == ITEMINDEX_NONE)
	{
		BLUE;
	}
	else
	{
		PUPPLE;
	}
	if (m_bLive == true)
	{
		string showWord;
		if (m_bHide == true)
		{
			for (int i = 0; i < m_Word.size(); i++)
			{
				showWord += "=";
			}
		}
		else
		{
			showWord = m_Word;
		}
		m_Interface.TextErase(showWord, m_Point.m_X, m_Point.m_Y);
		m_Point.m_Y++;
		if (m_Point.m_Y == HEIGHT - 1)
		{
			m_Interface.TextErase(showWord, m_Point.m_X, m_Point.m_Y - 1);
			m_bLive = false;
			m_bUnder = true;
			return;
		}
		// �Է� ���ڿ� �׷��� ��
		if ((m_Point.m_X + showWord.size() >= WIDTH - INPUTBOXWIDTH && m_Point.m_X <= WIDTH + INPUTBOXWIDTH - 1) && (m_Point.m_Y >= INPUTBOXPOSY && m_Point.m_Y <= INPUTBOXPOSY + INPUTBOXHEIGHT))
		{
			m_Interface.TextDraw(showWord, m_Point.m_X, m_Point.m_Y);
			BLUE;
			m_Interface.BoxDraw(WIDTH, INPUTBOXPOSY, INPUTBOXWIDTH, INPUTBOXHEIGHT);
			if (m_Point.m_Y != INPUTBOXPOSY + INPUTBOXHEIGHT)
			{
				return;
			}
		}
		m_Interface.TextDraw(showWord, m_Point.m_X, m_Point.m_Y);
		BLUE;
	}
}

void Word::EraseWord()
{
	m_Interface.TextErase(m_Word, m_Point.m_X, m_Point.m_Y);
	m_bLive = false;
}

void Word::SetItem()
{
	srand((unsigned)time(NULL));
	int index = rand() % 100;
	if (index <= 5)
	{
		m_ItemIndex = ITEMINDEX_SPDUP;
	}
	else if (index <= 10)
	{
		m_ItemIndex = ITEMINDEX_SPDDOWN;
	}
	else if (index <= 15)
	{
		m_ItemIndex = ITEMINDEX_PAUSE;
	}
	else if (index <= 20)
	{
		m_ItemIndex = ITEMINDEX_CLEAR;
	}
	else if (index <= 25)
	{
		m_ItemIndex = ITEMINDEX_HIDE;
	}
	else
	{
		m_ItemIndex = ITEMINDEX_NONE;
	}
}


Word::~Word()
{
}
