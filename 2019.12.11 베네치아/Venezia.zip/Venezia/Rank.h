#pragma once
#include "Interface.h"
#include "Player.h"

struct Ranker
{
	string m_Name;
	int m_Score;
	int m_Stage;
	bool m_bDrawFlag;
};

class Rank
{
private:
	Interface m_Interface;
	int m_RankerCount;
	Ranker* m_Ranker;
public:
	Rank();
	void RankMenu();
	void DrawRank();
	bool CheckRankFile();
	void LoadRankFile();
	void WriteRankFile(Player* player, int stage);
	~Rank();
};

