#include "GameManager.h"



GameManager::GameManager()
{
	m_Story = NULL;
	m_StoryLineCount = 0;
	CheckStoryFile();
	m_Stage = 1;
}

void GameManager::GameMenu()
{
	while (1)
	{
		char buf[256];
		sprintf(buf, "mode con: lines=%d cols=%d", HEIGHT + 4, WIDTH * 2);
		system(buf);
		SKY_BLUE;
		m_Interface.BoxDraw(0, 0, WIDTH, HEIGHT);
		BLUE;
		m_Interface.DrawMidText("�� �� �� �� ġ �� �� ��", WIDTH, HEIGHT / 2 - 10);
		m_Interface.DrawMidText("1.Game Start", WIDTH, HEIGHT / 2 - 3);
		m_Interface.DrawMidText("2.Rank", WIDTH, HEIGHT / 2);
		m_Interface.DrawMidText("3.Exit", WIDTH, HEIGHT / 2 + 3);
		m_Player.Init();
		m_Player.DrawPlayerInfo();
		ORIGINAL;
		switch (m_Interface.MenuSelectCursor(3, 3, WIDTH / 2 - 5, HEIGHT / 2 - 3))
		{
		case GAMEMENU_GAMESTART:
			DrawStory();
			m_Player.SetPlayerName();
			m_Player.DrawPlayerInfo();
			m_WordManager.Init(&m_Player);
			GameStart();
			break;
		case GAMEMENU_RANK:
			if (m_Rank.CheckRankFile() == true)
			{
				m_Rank.LoadRankFile();
				m_Rank.RankMenu();
			}
			break;
		case GAMEMENU_EXIT:
			return;
		}
	}
}

void GameManager::GameStart()
{
	bool bIsWrongAnswer = false;
	int wrongTimer;
	string answer;

	DrawStage();
	while (1)
	{
		m_WordManager.Update();
		// �÷��̾ �׾��� ���
		if (m_Player.GetPlayerDead() == true)
		{
			RED;
			m_Interface.DrawMidText("Game Over!!", WIDTH, HEIGHT / 2);
			Sleep(2000);
			BLUE;
			m_Rank.WriteRankFile(&m_Player, m_Stage);
			return;
		}
		if (bIsWrongAnswer == true)
		{
			if (clock() - wrongTimer >= 2000)
			{
				m_Interface.EraseMidText("FAILED COMPARE!!", WIDTH, INPUTBOXPOSY + 2);
				bIsWrongAnswer = false;
				m_Player.InitAnswer();
			}
		}
		else
		{
			m_Player.Input();
		}
		m_Player.Input();
		// ������ �������� ��
		if (m_Player.GetPlayerAnswerFlag() == true)
		{
			// �������� �Ǻ�
			if (m_WordManager.SearchAnswer())
			{
				bIsWrongAnswer = false;
				m_Player.InitAnswer();
				m_Player.PlusPlayerScore(PLUSSCORE);
				m_Player.DrawPlayerInfo();
			}
			else
			{
				if (bIsWrongAnswer == true)
				{
					continue;
				}
				wrongTimer = clock();
				bIsWrongAnswer = true;
				m_Interface.DrawMidText(m_Player.GetPlayerAnswer(), WIDTH, INPUTBOXPOSY + 2);
				m_Interface.DrawMidText("FAILED COMPARE!!", WIDTH, INPUTBOXPOSY + 2);
			}
		}
		// ���� ����� �����ϱ� ���� ������ ���� ��
		if (m_Player.GetPlayerScore() >= 1500 * m_Stage)
		{
			m_Stage++;
			DrawStage();
			m_WordManager.IncreaseSpeed();
			m_WordManager.Init(&m_Player);
		}
	}
}

void GameManager::CheckStoryFile()
{
	string line;
	ifstream load;
	int tmpLineCount = 0;
	load.open("����ġ��_���丮.txt");
	if (load.is_open())
	{
		load >> m_StoryLineCount;
		m_Story = new string[m_StoryLineCount];
		while (!load.eof())
		{
			getline(load, m_Story[tmpLineCount]);
			// �� �� ��Ÿ���� ���� ����
			if (tmpLineCount == 0)
			{
				m_Story[tmpLineCount].erase(0, 3);
			}
			m_Story[tmpLineCount].insert(0, "                  ");
			m_Story[tmpLineCount] += "                  ";
			tmpLineCount++;
			if (tmpLineCount == m_StoryLineCount)
			{
				return;
			}
		}
	}
	else
	{
		m_Interface.BoxErase(WIDTH, HEIGHT);
		m_Interface.DrawMidText("����ġ�� ���丮 ������ �����ϴ�.", WIDTH, HEIGHT / 2);
		getch();
	}
}

void GameManager::DrawStory()
{
	int CountClock, CurClock;
	int tmpCount = 0;
	int lineCount = 1;
	bool bPrintMaxLine = false;
	char tmpCh;
	m_Interface.BoxErase(WIDTH, HEIGHT);
	BLUE;
	m_Interface.BoxDraw(WIDTH, INPUTBOXPOSY, INPUTBOXWIDTH, INPUTBOXHEIGHT);
	m_Interface.DrawMidText("Skip : s", WIDTH, INPUTBOXPOSY + 2);
	CountClock = clock();
	while (1)
	{
		CurClock = clock();
		if (kbhit())
		{
			tmpCh = getch();
			if (tmpCh == 's')
			{
				return;
			}
		}
		// 10�� ��� ��
		if (!bPrintMaxLine)
		{
			if (CurClock - CountClock > 500)
			{
				m_Interface.DrawMidText(m_Story[tmpCount], WIDTH, 10 + tmpCount);
				tmpCount++;
				CountClock = CurClock;
				if (tmpCount == 10)
				{
					bPrintMaxLine = true;
					tmpCount = 0;
				}
			}
		}
		// 10�� ��� ��
		else
		{
			if (CurClock - CountClock > 500)
			{
				tmpCount = 0;
				for (int i = lineCount; i < m_StoryLineCount; i++)
				{
					m_Interface.DrawMidText(m_Story[i], WIDTH, 10 + tmpCount);
					tmpCount++;
					// 10�� ��� and ������ ���� ������� ��
					if (tmpCount == 10 && i == 25)
					{
						return;
					}
					// 10�� ��� ���� ��
					if (tmpCount == 10)
					{
						lineCount++;
						break;
					}
				}
				CountClock = CurClock;
			}
		}
	}
}

void GameManager::DrawStage()
{
	char buf[256];
	BLUE;
	m_Interface.BoxErase(WIDTH, HEIGHT);
	sprintf(buf, "�ڡ� %d Stage �١�", m_Stage);
	m_Interface.DrawMidText(buf, WIDTH, HEIGHT / 2);
	Sleep(1000);
	m_Interface.BoxErase(WIDTH, HEIGHT);
	m_Interface.BoxDraw(WIDTH, INPUTBOXPOSY, INPUTBOXWIDTH, INPUTBOXHEIGHT);
}


GameManager::~GameManager()
{
	if (m_Story != NULL)
	{
		delete[] m_Story;
	}
}
