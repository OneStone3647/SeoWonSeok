#include "Rank.h"



Rank::Rank()
{
	m_RankerCount = 0;
	m_Ranker = NULL;
}

void Rank::RankMenu()
{
	int height = 2;
	m_Interface.BoxErase(WIDTH, HEIGHT);
	m_Interface.DrawBlank(0, HEIGHT, WIDTH * 2 + 2, 4);
	BLUE;
	m_Interface.BoxDraw(WIDTH, height, INPUTBOXWIDTH, INPUTBOXHEIGHT);
	m_Interface.DrawMidText("Ranking", WIDTH, height + 2);
	for (int i = 2; i < WIDTH * 2 - 2; i++)
	{
		m_Interface.TextDraw("=", i, height + 6);
	}
	m_Interface.TextDraw("Name", WIDTH - 30, height + 8);
	m_Interface.TextDraw("Score", WIDTH, height + 8);
	m_Interface.TextDraw("Stage", WIDTH + 30, height + 8);
	DrawRank();
	ORIGINAL;
	getch();
	return;
}

void Rank::DrawRank()
{
	Ranker tmp;
	int height = 4;
	// �������� ����
	for (int i = 0; i < m_RankerCount - 1; i++)
	{
		for (int j = i + 1; j < m_RankerCount; j++)
		{
			if (m_Ranker[i].m_Score < m_Ranker[j].m_Score)
			{
				tmp = m_Ranker[j];
				m_Ranker[j] = m_Ranker[i];
				m_Ranker[i] = tmp;
			}
		}
	}
	for (int i = 0; i < m_RankerCount; i++)
	{
		m_Interface.TextDraw(m_Ranker[i].m_Name, WIDTH - 30, height + 10 + 2 * i);
		m_Interface.TextDraw(to_string(m_Ranker[i].m_Score), WIDTH, height + 10 + 2 * i);
		m_Interface.TextDraw(to_string(m_Ranker[i].m_Stage), WIDTH + 30, height + 10 + 2 * i);
	}
}

bool Rank::CheckRankFile()
{
	string tmp;
	ifstream load;
	load.open("Rank.txt");
	m_RankerCount = 0;
	if (load.is_open())
	{
		while (!load.eof())
		{
			getline(load, tmp);
			m_RankerCount++;
		}
		// ������ ���� ����
		m_RankerCount--;
		return true;
	}
	else
	{
		m_Interface.BoxErase(WIDTH, HEIGHT);
		m_Interface.DrawMidText("Rank������ �����ϴ�.", WIDTH, HEIGHT / 2);
		return false;
	}
}

void Rank::LoadRankFile()
{
	if (m_Ranker != NULL)
	{
		delete[] m_Ranker;
	}
	m_Ranker = new Ranker[m_RankerCount];
	ifstream load;
	load.open("Rank.txt");
	if (load.is_open())
	{
		while (!load.eof())
		{
			for (int i = 0; i < m_RankerCount; i++)
			{
				load >> m_Ranker[i].m_Name;
				load >> m_Ranker[i].m_Stage;
				load >> m_Ranker[i].m_Score;
			}
		}
	}
	else
	{
		m_Interface.BoxErase(WIDTH, HEIGHT);
		m_Interface.DrawMidText("Rank������ �����ϴ�.", WIDTH, HEIGHT / 2);
		return;
	}
}

void Rank::WriteRankFile(Player * player, int stage)
{
	ofstream save("Rank.txt", ios::app);
	string tmp;
	if (save.is_open())
	{
		save << player->GetPlayerName() << " ";
		save << stage << " ";
		save << player->GetPlayerScore() << endl;
		save.close();
	}
}


Rank::~Rank()
{
	if (m_Ranker != NULL)
	{
		delete[] m_Ranker;
	}
}
