#pragma once
#include "Interface.h"
#include "Player.h"
#include "WordManager.h"
#include "Rank.h"

enum GAMEMENU
{
	GAMEMENU_GAMESTART = 1,
	GAMEMENU_RANK,
	GAMEMENU_EXIT
};

class GameManager
{
private:
	Interface m_Interface;
	Player m_Player;
	WordManager m_WordManager;
	Rank m_Rank;
	string* m_Story;
	int m_StoryLineCount;
	int m_Stage;
public:
	GameManager();
	void GameMenu();
	void GameStart();
	void CheckStoryFile();
	void DrawStory();
	void DrawStage();
	~GameManager();
};

