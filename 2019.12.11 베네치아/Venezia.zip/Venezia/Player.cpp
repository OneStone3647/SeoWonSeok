#include "Player.h"



Player::Player()
{
	m_Name = "???";
	m_Life = 9;
	m_Score = 0;
	m_bAnswerFlag = false;
	m_bDead = false;
}

void Player::Init()
{
	m_Name = "???";
	m_Life = 9;
	m_Score = 0;
	m_bAnswerFlag = false;
	m_bDead = false;
}

void Player::Input()
{
	if (kbhit())
	{
		char tmp = getch();
		if (m_bAnswerFlag == false)
		{
			BLUE;
			if (tmp == ENTER)
			{
				m_Interface.EraseMidText(m_Answer, WIDTH, INPUTBOXPOSY + 2);
				m_bAnswerFlag = true;
				return;
			}
			else if (tmp == BACKSPACE)
			{
				if (m_Answer.size() != 0)
				{
					m_Interface.EraseMidText(m_Answer, WIDTH, INPUTBOXPOSY + 2);
					m_Answer.pop_back();
					if (m_Answer.size() < 20)
					{
						m_Interface.EraseMidText("20���� �ʰ�!!", WIDTH, INPUTBOXPOSY - 3);
					}
					m_Interface.DrawMidText(m_Answer, WIDTH, INPUTBOXPOSY + 2);
					return;
				}
				m_bAnswerFlag = false;
			}
			if (m_Answer.size() < 20)
			{
				m_Answer += tmp;
				m_bAnswerFlag = false;
			}
			else
			{
				m_Interface.EraseMidText(m_Answer, WIDTH, INPUTBOXPOSY + 2);
				m_Interface.DrawMidText("20���� �ʰ�!!", WIDTH, INPUTBOXPOSY - 3);
			}
			m_Interface.DrawMidText(m_Answer, WIDTH, INPUTBOXPOSY + 2);
		}
	}	
}

void Player::InitAnswer()
{
	m_bAnswerFlag = false;
	m_Answer.clear();
}

void Player::DecreasePlayerLife()
{
	ErasePlayerInfo();
	m_Life--;
	DrawPlayerInfo();
	if (m_Life <= 0)
	{
		m_bDead = true;
	}
}

void Player::DrawPlayerInfo()
{
	string life = "Life : ";
	for (int i = 0; i < m_Life; i++)
	{
		life += "��";
	}
	RED;
	m_Interface.TextDraw(life, 1, HEIGHT + 1);
	m_Interface.TextDraw("Score : " + to_string(m_Score), 61, HEIGHT + 1);
	m_Interface.TextDraw("Name : " + m_Name, 112, HEIGHT + 1);
	ORIGINAL;
}

void Player::ErasePlayerInfo()
{
	string life = "Life : ";
	for (int i = 0; i < m_Life; i++)
	{
		life += "��";
	}
	RED;
	m_Interface.TextErase(life, 1, HEIGHT + 1);
	m_Interface.TextErase("Score : " + to_string(m_Score), 61, HEIGHT + 1);
	m_Interface.TextErase("Name : " + m_Name, 112, HEIGHT + 1);
}

void Player::SetPlayerName()
{
	string name;
	char tmp;
	m_Interface.BoxErase(WIDTH, HEIGHT);
	BLUE;
	m_Interface.BoxDraw(WIDTH, INPUTBOXPOSY, INPUTBOXWIDTH, INPUTBOXHEIGHT);
	m_Interface.DrawMidText("�̸� �Է�", WIDTH, INPUTBOXPOSY - 4);
	while (1)
	{
		if (kbhit())
		{
			tmp = getch();
			if (tmp == BACKSPACE && name.size() != 0)
			{
				m_Interface.EraseMidText(name, WIDTH, INPUTBOXPOSY + 2);
				name.pop_back();
				m_Interface.DrawMidText(name, WIDTH, INPUTBOXPOSY + 2);
				if (name.size() < 10)
				{
					m_Interface.EraseMidText("10���� �ʰ�!!", WIDTH, INPUTBOXPOSY - 3);
				}
				continue;
			}
			if (name.size() < 10)
			{
				if (tmp == ENTER)
				{
					m_Name = name;
					return;
				}
				name += tmp;
				m_Interface.DrawMidText(name, WIDTH, INPUTBOXPOSY + 2);
			}
			else
			{
				m_Interface.DrawMidText("10���� �ʰ�!!", WIDTH, INPUTBOXPOSY - 3);
			}
		}
	}
}


Player::~Player()
{
}
