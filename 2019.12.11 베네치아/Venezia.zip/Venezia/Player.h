#pragma once
#include "Interface.h"


class Player
{
private:
	Interface m_Interface;
	string m_Name;
	int m_Life;
	int m_Score;
	string m_Answer;
	bool m_bAnswerFlag;
	bool m_bDead;
public:
	Player();
	void Init();
	void Input();
	void InitAnswer();
	void DecreasePlayerLife();
	void DrawPlayerInfo();
	void ErasePlayerInfo();
	void SetPlayerName();
	inline void SetPlayerbAnswerFlag(bool flag)
	{
		m_bAnswerFlag = flag;
	}
	inline void PlusPlayerScore(int score)
	{
		m_Score += score;
	}
	inline string GetPlayerName()
	{
		return m_Name;
	}
	inline int GetPlayerLife()
	{
		return m_Life;
	}
	inline int GetPlayerScore()
	{
		return m_Score;
	}
	inline string GetPlayerAnswer()
	{
		return m_Answer;
	}
	inline bool GetPlayerAnswerFlag()
	{
		return m_bAnswerFlag;
	}
	inline bool GetPlayerDead()
	{
		return m_bDead;
	}
	~Player();
};

