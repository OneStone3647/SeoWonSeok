#include "WordManager.h"



WordManager::WordManager()
{
	m_Word = NULL;
	m_SetSpeed = 1500;
	m_DropSpeed = 1000;
	m_bPauseFlag = false;
	m_bHideFlag = false;
	CheckWordFile();
	srand((unsigned)time(NULL));
}

void WordManager::CheckWordFile()
{
	string tmp;
	ifstream load;
	load.open("Word.txt");
	if (load.is_open())
	{
		while (!load.eof())
		{
			load >> m_WordCount;
			m_Word = new Word[m_WordCount];
			for (int i = 0; i < m_WordCount; i++)
			{
				load >> tmp;
				m_Word[i].SetWord(tmp);
			}
		}
	}
	else
	{
		m_Interface.BoxErase(WIDTH, HEIGHT);
		m_Interface.DrawMidText("Word ������ �����ϴ�.", WIDTH, HEIGHT / 2);
		getch();
	}
}

void WordManager::Init(Player * player)
{
	//�÷��̾� ���� ����
	m_Player = player;
	for (int i = 0; i < m_WordCount; i++)
	{
		m_Word[i].Init();
	}
	m_SetSpeed = 1500;
	m_DropSpeed = 1000;
}

void WordManager::Update()
{
	if (m_bPauseFlag == false)
	{
		if (clock() - m_SetTimer >= m_SetSpeed)
		{
			SetWord();
			m_SetTimer = clock();
		}
		if (clock() - m_DropTimer >= m_DropSpeed)
		{
			DropWord();
			m_DropTimer = clock();
		}
	}
	if (m_bPauseFlag == true)
	{
		if (clock() - m_PauseTimer >= ITEM_ACTIVE_TIME)
		{
			m_bPauseFlag = false;
		}
	}
	if (m_bHideFlag == true)
	{
		if (clock() - m_HideTimer >= ITEM_ACTIVE_TIME)
		{
			HideWord(false);
			m_bHideFlag = false;
		}
	}
}

void WordManager::SetWord()
{
	int x;
	int wordIndex;
	while (1)
	{
		wordIndex = rand() % m_WordCount;		
		if (m_Word[wordIndex].GetLive() == false)
		{
			while (1)
			{
				x = rand() % (WIDTH * 2) + 2;
				if (x < (WIDTH * 2) - m_Word[wordIndex].GetWord().size() - 1)
				{
					break;
				}
			}
			m_Word[wordIndex].SetPointX(x);
			m_Word[wordIndex].SetPointY(1);
			m_Word[wordIndex].SetWordLive(true);
			m_Word[wordIndex].SetWordUnder(false);
			m_Word[wordIndex].SetItem();
			return;
		}
		return;
	}
}

void WordManager::DropWord()
{
	for (int i = 0; i < m_WordCount; i++)
	{
		if (m_Word[i].GetLive() == true)
		{
			m_Word[i].DrawWord();
		}
		if (m_Word[i].GetUnder() == true)
		{
			m_Player->DecreasePlayerLife();
			m_Word[i].SetWordUnder(false);
		}
	}
}

bool WordManager::SearchAnswer()
{
	for (int i = 0; i < m_WordCount; i++)
	{
		if (m_Word[i].GetLive() == true && m_Word[i].GetWord() == m_Player->GetPlayerAnswer())
		{
			m_Word[i].EraseWord();
			m_Word[i].SetWordLive(false);
			ActiveItem(m_Word[i].GetItemIndex());
			return true;
		}
	}
	return false;
}

void WordManager::ActiveItem(ITEMINDEX index)
{
	switch (index)
	{
	case ITEMINDEX_SPDUP:
		IncreaseSpeed();
		break;
	case ITEMINDEX_SPDDOWN:
		DecreaseSpeed();
		break;
	case ITEMINDEX_PAUSE:
		m_PauseTimer = clock();
		PauseWord();
		break;
	case ITEMINDEX_CLEAR:
		ClearWord();
		break;
	case ITEMINDEX_HIDE:
		m_HideTimer = clock();
		HideWord(true);
		break;
	case ITEMINDEX_NONE:
		return;
	}
}

void WordManager::IncreaseSpeed()
{
	if (m_SetSpeed > 300)
	{
		m_SetSpeed -= 300;
	}
	if (m_DropSpeed > 200)
	{
		m_DropSpeed -= 200;
	}
}

void WordManager::DecreaseSpeed()
{
	if (m_SetSpeed < 1500)
	{
		m_SetSpeed += 300;
	}
	if (m_DropSpeed < 800)
	{
		m_DropSpeed += 200;
	}
}

void WordManager::PauseWord()
{
	m_bPauseFlag = true;
}

void WordManager::ClearWord()
{
	for (int i = 0; i < m_WordCount; i++)
	{
		if (m_Word[i].GetLive() == true)
		{
			m_Word[i].EraseWord();
			m_Player->PlusPlayerScore(PLUSSCORE);
		}
	}
}

void WordManager::HideWord(bool flag)
{
	for (int i = 0; i < m_WordCount; i++)
	{
		m_Word[i].SetHideWord(flag);
		if (m_Word[i].GetLive() == true)
		{
			string showWord;
			for (int j = 0; j < m_Word[i].GetWord().size(); j++)
			{
				showWord += "=";
			}
			PUPPLE;
			m_Interface.TextErase(showWord, m_Word[i].GetPointX(), m_Word[i].GetPointY());
			m_Interface.TextDraw(showWord, m_Word[i].GetPointX(), m_Word[i].GetPointY());
			BLUE;
		}
	}
	m_bHideFlag = true;
}


WordManager::~WordManager()
{
	if (m_Word != NULL)
	{
		delete[] m_Word;
	}
}
