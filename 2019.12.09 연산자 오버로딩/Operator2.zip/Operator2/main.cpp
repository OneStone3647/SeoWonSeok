#include "Time.h"

void main()
{
	int m_Day = 1;
	int m_Select;
	Time totalTime(0, 0);
	Time newTime(0, 0);
	while (1)
	{
		system("cls");
		totalTime.ShowTime();
		cout << "=====���� �ð� ���� ���α׷�(" << m_Day << "Day)=====" << endl;
		cout << "          1.�ð� ���" << endl;
		cout << "          2.����" << endl;
		cout << "          �Է� : ";
		cin >> m_Select;
		switch (m_Select)
		{
		case 1:
			newTime.SetTime();
			totalTime = totalTime + newTime;
			m_Day++;
			break;
		case 2:
			system("cls");
			totalTime.ShowTime();
			return;
		}
	}
}