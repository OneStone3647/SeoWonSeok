#pragma once
#include <iostream>
#include <Windows.h>

using namespace std;
class Time
{
private:
	int m_Hour;
	int m_Min;
public:
	Time();
	Time(int hour, int min);
	void ShowTime();
	void SetTime();
	Time operator + (Time time);
	~Time();
};

