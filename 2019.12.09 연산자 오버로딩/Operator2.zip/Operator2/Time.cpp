#include "Time.h"



Time::Time()
{
}

Time::Time(int hour, int min)
{
	m_Hour = hour;
	m_Min = min;
}

void Time::ShowTime()
{
	cout << "�� ���� �ð� : " << m_Hour << " : " << m_Min << endl;
}

void Time::SetTime()
{
	cout << "�ð� : ";
	cin >> m_Hour;
	cout << "�� : ";
	cin >> m_Min;
}

Time Time::operator+(Time time)
{
	m_Hour += time.m_Hour;
	m_Min += time.m_Min;
	if (m_Min >= 60)
	{
		m_Min -= 60;
		m_Hour++;
	}
	return Time(m_Hour, m_Min);
}


Time::~Time()
{
}
