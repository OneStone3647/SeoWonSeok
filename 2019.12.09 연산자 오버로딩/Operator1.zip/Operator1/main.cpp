#include "Point.h"

void main()
{
	Point ov1(10, 20), ov2(5, 40);
	ov1.Print();
	ov2.Print();
	cout << "��ü / ��ü" << endl;
	ov2 = ov1 / ov2;
	ov2.Print();
}