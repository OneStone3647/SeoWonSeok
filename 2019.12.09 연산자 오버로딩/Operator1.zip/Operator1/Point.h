#pragma once
#include <iostream>
using namespace std;

class Point
{
private:
	int x, y;
public:
	Point();
	Point(int a, int b);
	void Print();
	Point operator/(Point tmp);
	~Point();
};

