#include "Point.h"



Point::Point()
{
}

Point::Point(int a, int b)
{
	x = a;
	y = b;
}

void Point::Print()
{
	cout << "x = " << x << ",y = " << y << "\n";
}

Point Point::operator/(Point tmp)
{
	if (x > tmp.x)
	{
		x = x / tmp.x;
	}
	else if (x < tmp.x)
	{
		x = tmp.x / x;
	}
	else
	{
		x = 1;
	}

	if (y > tmp.y)
	{
		y = y / tmp.y;
	}
	else if (y < tmp.y)
	{
		y = tmp.y / y;
	}
	else
	{
		y = 1;
	}
	return Point(x, y);
}


Point::~Point()
{
}
